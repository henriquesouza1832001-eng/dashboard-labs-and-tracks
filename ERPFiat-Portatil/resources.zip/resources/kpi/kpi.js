'use strict';
window.onerror=function(msg,src,line,col,err){var b=document.getElementById('debug-bar');if(b){b.style.display='block';b.textContent+='ERRO linha '+line+': '+msg+'\n';}};
window.addEventListener('unhandledrejection',function(e){var b=document.getElementById('debug-bar');if(b){b.style.display='block';b.textContent+='PROMISE: '+(e.reason?.stack||e.reason)+'\n';}});
if(typeof Neutralino!=='undefined'&&!window._neuInit){window._neuInit=true;Neutralino.init();}

const $=id=>document.getElementById(id);
const fmt=(v,d=0)=>isNaN(v)?'0':Number(v).toFixed(d);
const fmtRK=v=>{if(v===null||v===undefined)return'—';const n=Number(v);if(Math.abs(n)>=1e6)return'R$'+(n/1e6).toFixed(1)+'M';if(Math.abs(n)>=1e3)return'R$'+(n/1e3).toFixed(1)+'k';return'R$'+Math.round(n);};
const tnome=n=>n&&n.length>18?n.slice(0,16)+'…':n||'—';
const fmtDate=s=>{if(!s)return'—';const p=s.split('-');return p.length===3?p[2]+'/'+p[1]+'/'+p[0]:s;};

function tick(){const n=new Date();$('clock').textContent=[n.getHours(),n.getMinutes(),n.getSeconds()].map(x=>String(x).padStart(2,'0')).join(':');}
tick();setInterval(tick,1000);
function preencherMicroCards(){
  const dOb=lerCache(CACHES.obras);
  if(dOb){
    const obras=dOb.obras||[];
    const lanc=dOb.lancamentos||[];
    const budget=dOb.budget||[];
    const budgTotal=budget.reduce((s,b)=>s+(b.budgetAprov||0),0);
    const real=lanc.reduce((s,l)=>s+l.qtd*l.precoUnit,0);
    const emAnd=obras.filter(o=>o.status==='Em Andamento').length;
    const conc=obras.filter(o=>o.status==='Concluído').length;
    const pct=budgTotal>0?Math.round(real/budgTotal*100):0;
    document.getElementById('mkpis-obras').innerHTML=
      mkMicro(obras.length,'Total obras','c-azul')+
      mkMicro(emAnd,'Em andamento','c-laranja')+
      mkMicro(fmtRK(budgTotal),'Budget','c-azul')+
      mkMicro(pct+'%','% realizado',pct>90?'c-vermelho':'c-verde');
    document.getElementById('mfoot-obras').textContent=
      'Saldo: '+fmtRK(budgTotal-real)+' · Concluídas: '+conc;
    const sm={};obras.forEach(o=>{sm[o.status]=(sm[o.status]||0)+1;});
    const sl=Object.entries(sm).filter(x=>x[1]);
    setTimeout(()=>desenharMicroDonut('mcv-obras',sl.map(x=>x[0]),sl.map(x=>x[1]),['#e3711a','#3fb950','#58a6ff','#f85149']),80);
  }
  const dCap=lerCache(CACHES.capex);
  if(dCap){
    const obras=dCap.obras||[];
    const budget=dCap.budget||[];
    const lanc=dCap.lancamentos||[];
    const budgTotal=budget.reduce((s,b)=>s+(b.budgetAprov||0),0);
    const real=lanc.reduce((s,l)=>s+l.qtd*l.precoUnit,0);
    const pct=budgTotal>0?Math.round(real/budgTotal*100):0;
    const saldo=budgTotal-real;
    document.getElementById('mkpis-capex').innerHTML=
      mkMicro(fmtRK(budgTotal),'Budget total','c-azul')+
      mkMicro(fmtRK(real),'Realizado','c-laranja')+
      mkMicro(fmtRK(saldo),'Saldo',saldo<0?'c-vermelho':'c-verde')+
      mkMicro(pct+'%','% realizado',pct>90?'c-vermelho':'c-verde');
    document.getElementById('mfoot-capex').textContent='Budget: '+fmtRK(budgTotal)+' · Saldo: '+fmtRK(saldo);
    const sm={};obras.forEach(o=>{sm[o.status]=(sm[o.status]||0)+1;});
    const sl=Object.entries(sm).filter(x=>x[1]);
    setTimeout(()=>desenharMicroDonut('mcv-capex',sl.map(x=>x[0]),sl.map(x=>x[1]),['#e3711a','#3fb950','#2E5FA3','#f85149']),80);
  }
  const dCod=lerCache(CACHES.codin);
  if(dCod){
    const pessoas=dCod.pessoas||[];
    const ativos=pessoas.filter(p=>p.status==='Ativo'||!p.status).length;
    const semPonto=pessoas.filter(p=>!p.ponto&&!p.pontoId).length;
    const perfis=new Set(pessoas.map(p=>p.perfil||p.cargo||'Operador')).size;
    document.getElementById('mkpis-codin').innerHTML=
      mkMicro(pessoas.length,'Total pessoas','c-azul')+
      mkMicro(ativos,'Ativas','c-verde')+
      mkMicro(semPonto,'Sem ponto',semPonto>0?'c-amarelo':'c-verde')+
      mkMicro(perfis,'Perfis','c-azul');
    document.getElementById('mfoot-codin').textContent=Math.round(ativos/Math.max(pessoas.length,1)*100)+'% ativos · '+semPonto+' sem ponto';
    setTimeout(()=>desenharMicroDonut('mcv-codin',['Ativos','Inativos'],[ativos||1,pessoas.length-ativos||1],['#3fb950','#f85149']),80);
  }
  const dCnf=lerCache(CACHES.conforto);
  if(dCnf){
    const regs=dCnf.registros||[];
    const conform=regs.filter(r=>r.status==='Conforme'||r.situacao==='OK').length;
    const nconf=regs.filter(r=>r.status==='Não Conforme'||r.situacao==='NOK').length;
    const areas=new Set(regs.map(r=>r.area||r.local||'')).size;
    const pct=regs.length>0?Math.round(conform/regs.length*100):0;
    document.getElementById('mkpis-conforto').innerHTML=
      mkMicro(regs.length,'Registros','c-azul')+
      mkMicro(conform,'Conformes','c-verde')+
      mkMicro(nconf,'Não conformes',nconf>0?'c-vermelho':'c-verde')+
      mkMicro(pct+'%','Conformidade',pct>80?'c-verde':'c-vermelho');
    document.getElementById('mfoot-conforto').textContent=areas+' áreas · '+pct+'% conformidade';
    setTimeout(()=>desenharMicroDonut('mcv-conforto',['Conforme','Não Conforme'],[conform||1,nconf||1],['#3fb950','#f85149']),80);
  }
  const dErg=lerCache(CACHES.ergonomia);
  if(dErg){
    const avs=dErg.avaliacoes||[];
    const ok=avs.filter(a=>a.resultado==='OK'||a.status==='Aprovado').length;
    const nok=avs.filter(a=>a.resultado==='NOK'||a.status==='Reprovado').length;
    const pend=avs.length-ok-nok;
    const postos=new Set(avs.map(a=>a.posto||a.local||'')).size;
    document.getElementById('mkpis-ergonomia').innerHTML=
      mkMicro(avs.length,'Avaliações','c-azul')+
      mkMicro(ok,'Aprovadas','c-verde')+
      mkMicro(nok,'Reprovadas',nok>0?'c-vermelho':'c-verde')+
      mkMicro(postos,'Postos','c-azul');
    document.getElementById('mfoot-ergonomia').textContent=avs.length>0?Math.round(ok/avs.length*100)+'% aprovadas · '+pend+' pendentes':'—';
    setTimeout(()=>desenharMicroDonut('mcv-ergonomia',['Aprovadas','Reprovadas','Pendentes'],[ok||1,nok||1,pend||1],['#3fb950','#f85149','#d29922']),80);
  }
  const dCh=lerCache(CACHES.chamados);
  if(dCh){
    const cham=dCh.chamados||(Array.isArray(dCh)?dCh:[]);
    const total=cham.length;
    const abertos=cham.filter(c=>c.status==='Aberto').length;
    const alta=cham.filter(c=>c.prioridade==='Alta'||c.prioridade==='Crítica').length;
    const resolvidos=cham.filter(c=>['Resolvido','Fechado','Concluído'].includes(c.status)).length;
    document.getElementById('mkpis-chamados').innerHTML=
      mkMicro(total,'Total','c-azul')+
      mkMicro(abertos,'Abertos',abertos>0?'c-vermelho':'c-verde')+
      mkMicro(alta,'Alta prio.',alta>0?'c-vermelho':'c-verde')+
      mkMicro(resolvidos,'Resolvidos','c-verde');
    document.getElementById('mfoot-chamados').textContent=
      Math.round(resolvidos/Math.max(total,1)*100)+'% resolvidos · '+alta+' críticos';
    const sm={};cham.forEach(c=>{const s=c.status||'Aberto';sm[s]=(sm[s]||0)+1;});
    const sl=Object.entries(sm).filter(x=>x[1]);
    setTimeout(()=>desenharMicroDonut('mcv-chamados',sl.map(x=>x[0]),sl.map(x=>x[1]),['#f85149','#e3711a','#3fb950','#58a6ff']),80);
  }
}

function mkMicro(val,lbl,cls){
  return`<div class="mod-micro-kpi"><div class="mod-micro-lbl">${lbl}</div><div class="mod-micro-val ${cls}">${val}</div></div>`;
}

function desenharMicroDonut(id,labels,vals,cores){
  const cv=document.getElementById(id);if(!cv)return;
  const pai=cv.parentElement;
  pai.id=pai.id||'donut-'+id;
  desenharDonutSVG(pai.id,labels,vals,cores);
}
(function loadLogos(){
  const wrap=document.getElementById('kpi-logos');if(!wrap)return;
  try{const cfg=JSON.parse(localStorage.getItem('hub-config')||'{}');(cfg.logos||[]).forEach(src=>{if(!src)return;const img=document.createElement('img');img.src=src;img.style.cssText='height:32px;width:auto;max-width:100px;object-fit:contain;border-radius:4px';wrap.appendChild(img);});}catch(e){}
})();
(function loadSidebar(){
  try{
    const cfg=JSON.parse(localStorage.getItem('hub-config')||'{}');
    const id=cfg.identidade||{};
    const n=$('kpi-inst-nome'),s=$('kpi-inst-sub'),b=$('kpi-inst-badge');
    if(n)n.textContent=id.instNome||id.brand||'—';
    if(s)s.textContent=id.instSub||'—';
    if(b)b.textContent=id.instBadge||'—';
  }catch(e){}
  try{
    const wrap=$('kpi-acts');
    if(!wrap)return;
    const raw=localStorage.getItem('hub-atividades');
    if(!raw){wrap.innerHTML='<div style="font-size:10px;color:var(--text-dim);padding:8px 0">Sem atividades carregadas</div>';return;}
    const data=JSON.parse(raw);
    const ativs=Array.isArray(data)?data:(data.atividades||[]);
    if(!ativs.length){wrap.innerHTML='<div style="font-size:10px;color:var(--text-dim);padding:8px 0">Nenhuma atividade encontrada</div>';return;}
    const hoje=new Date().toISOString().slice(0,10);
    const amanha=new Date(Date.now()+86400000).toISOString().slice(0,10);
    const semana=new Date(Date.now()+7*86400000).toISOString().slice(0,10);
    const sorted=ativs.slice().sort((a,b)=>{
      const pa=a.prazo||'9999-99-99';
      const pb=b.prazo||'9999-99-99';
      return pa.localeCompare(pb);
    });
    wrap.innerHTML=sorted.slice(0,12).map(a=>{
      const done=a.status==='done';
      const prazo=a.prazo||'';
      const vencida=prazo&&prazo<hoje&&!done;
      const venceHoje=prazo===hoje&&!done;
      const venceAmanha=prazo===amanha&&!done;
      const semana_=prazo&&prazo<=semana&&prazo>amanha&&!done;
      let pilClass='kpi-pl';
      let pilTxt='';
      if(done){pilClass='kpi-pl';pilTxt='OK';}
      else if(vencida){pilClass='kpi-ph';pilTxt='ATRAS.';}
      else if(venceHoje){pilClass='kpi-ph';pilTxt='HOJE';}
      else if(venceAmanha){pilClass='kpi-pm';pilTxt='AMANHÃ';}
      else if(semana_){pilClass='kpi-pm';pilTxt='SEM.';}
      else if(prazo){pilClass='kpi-pl';pilTxt=prazo.slice(8)+'/'+prazo.slice(5,7);}
      const chkClass=done?'done':vencida||venceHoje?'pend':'';
      return`<div class="kpi-act-item">
        <div class="kpi-act-chk ${chkClass}"></div>
        <div class="kpi-act-txt ${done?'done':''}" title="${a.titulo||a.nome||''}">${(a.titulo||a.nome||'Sem título').slice(0,28)}</div>
        ${pilTxt?`<div class="kpi-pil ${pilClass}">${pilTxt}</div>`:''}
      </div>`;
    }).join('');
  }catch(e){
    const wrap=$('kpi-acts');
    if(wrap)wrap.innerHTML='<div style="font-size:10px;color:var(--red);padding:8px 0">Erro ao carregar</div>';
  }
})();


function lerCache(chave){const txt=localStorage.getItem(chave);if(!txt)return null;try{return JSON.parse(txt);}catch(e){return null;}}
const CACHES={obras:'obras-dados-cache',capex:'capex-dados-cache',chamados:'chamados-facilities-dados',codin:'codin-dados-cache',conforto:'conforto-dados-cache',ergonomia:'ergonomia-dados-cache',acesso:'controle-acesso-dados'};
let moduloAtivo=null;
const TODOS_MODULOS=['obras','capex','chamados','codin','conforto','ergonomia','acesso'];
preencherMicroCards();



function alternarModulo(id){
  const card=document.getElementById('mod-'+id);
  if(!card)return;
  if(moduloAtivo===id){
    moduloAtivo=null;
    document.getElementById('painel-expandido-global')?.remove();
    document.querySelector('.modulos-wrap').style.display='';
    TODOS_MODULOS.forEach(m=>{
      const c=document.getElementById('mod-'+m);
      if(c)c.classList.remove('oculto','expandido','ativo');
    });
    return;
  }
  moduloAtivo=id;
  TODOS_MODULOS.forEach(m=>{
    const c=document.getElementById('mod-'+m);
    if(!c)return;
    if(m===id){
      c.classList.remove('oculto');
      c.classList.add('ativo');
    } else {
      c.classList.remove('expandido','ativo');
      c.classList.add('oculto');
    }
  });
  document.querySelector('.modulos-wrap').style.display='none';
  document.getElementById('painel-expandido-global')?.remove();
  const mainScroll=document.querySelector('.main-scroll');
  const painel=document.createElement('div');
  painel.id='painel-expandido-global';
painel.style.cssText='padding:16px 20px 20px';
  const nomes={obras:'Obras',capex:'CAPEX',chamados:'Chamados',codin:'CODIN',conforto:'Conforto',ergonomia:'Ergonomia',acesso:'Controle de Acesso'};
  const header=document.createElement('div');
  header.style.cssText='display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-shrink:0';
  header.innerHTML=`<div style="font-size:10px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.08em;display:flex;align-items:center;gap:8px"><span style="display:inline-block;width:2px;height:11px;background:var(--blue-light);border-radius:2px"></span>${nomes[id]}</div>
    <button onclick="alternarModulo('${id}')" style="font-size:10px;color:var(--text-muted);cursor:pointer;padding:4px 12px;border:1px solid var(--border);border-radius:5px;background:var(--surface);font-family:var(--font);transition:all .12s" onmouseover="this.style.color='var(--blue-light)';this.style.borderColor='var(--blue-light)'" onmouseout="this.style.color='var(--text-muted)';this.style.borderColor='var(--border)'">✕ fechar</button>`;
  painel.appendChild(header);
  const conteudo=document.createElement('div');
  conteudo.style.cssText='flex:1;min-height:0;overflow-y:auto';
  painel.appendChild(conteudo);
  mainScroll.appendChild(painel);
  const d=lerCache(CACHES[id]);
  if(id==='obras') renderObras(conteudo,d);
else if(id==='chamados') renderChamados(conteudo,d);
else if(id==='capex') renderCapex(conteudo,d);
else if(id==='codin') renderCodin(conteudo,d);
else if(id==='conforto') renderConforto(conteudo,d);
else if(id==='ergonomia') renderErgonomia(conteudo,d);
else conteudo.innerHTML='<div class="sem-dados" style="margin-top:40px">Módulo em desenvolvimento.<br><span style="font-size:10px">Em breve disponível.</span></div>';
}

/* ══════════════════════════════════════════════
   CANVAS HELPERS
══════════════════════════════════════════════ */
function resolveW(id){const cv=$(id);if(!cv)return null;const pw=cv.parentElement?cv.parentElement.clientWidth:0;if(pw>0)cv.width=pw;return cv;}

function desenharBarrasH(id,labels,vals,cores){
  const cv=resolveW(id);if(!cv)return;
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');ctx.clearRect(0,0,W,H);
  if(!vals||!vals.length)return;
  const max=Math.max(...vals.map(Math.abs))||1,n=labels.length;
  const rowH=H/n,barH=Math.min(rowH*.55,18),lW=68,aW=W-lW-44;
  ctx.font='9px IBM Plex Mono,monospace';
  labels.forEach((lbl,i)=>{
    const v=vals[i],bw=(Math.abs(v)/max)*aW,y=i*rowH+(rowH-barH)/2;
    const cor=Array.isArray(cores)?cores[i%cores.length]:cores;
    ctx.fillStyle='#e8edf5';ctx.beginPath();if(ctx.roundRect)ctx.roundRect(lW,y,aW,barH,2);else ctx.rect(lW,y,aW,barH);ctx.fill();
    ctx.fillStyle=cor;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(lW,y,bw,barH,2);else ctx.rect(lW,y,bw,barH);ctx.fill();
    ctx.fillStyle='#8b949e';ctx.textAlign='right';ctx.fillText(String(lbl).slice(0,12),lW-5,y+barH/2+3.5);
    ctx.fillStyle=cor;ctx.textAlign='left';
    const t=Math.abs(v)>999?fmtRK(v):(fmt(v,1)+(Math.abs(v)<=200&&v>0?'%':''));
    ctx.fillText(t,lW+bw+4,y+barH/2+3.5);
  });
}

function desenharSpark(id,labels,vals,cor){
  const cv=resolveW(id);if(!cv)return;
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');ctx.clearRect(0,0,W,H);
  if(!vals||vals.length<2)return;
  const max=Math.max(...vals)||1,pT=8,pB=20,pL=5,pR=8;
  const uw=(W-pL-pR)/(vals.length-1);
  const pts=vals.map((v,i)=>({x:pL+i*uw,y:pT+(1-v/max)*(H-pT-pB)}));
  const g=ctx.createLinearGradient(0,pT,0,H-pB);
  g.addColorStop(0,cor+'44');g.addColorStop(1,cor+'00');
  ctx.beginPath();ctx.moveTo(pts[0].x,H-pB);pts.forEach(p=>ctx.lineTo(p.x,p.y));ctx.lineTo(pts[pts.length-1].x,H-pB);ctx.closePath();
  ctx.fillStyle=g;ctx.fill();
  ctx.beginPath();ctx.moveTo(pts[0].x,pts[0].y);pts.forEach(p=>ctx.lineTo(p.x,p.y));
  ctx.strokeStyle=cor;ctx.lineWidth=2;ctx.lineJoin='round';ctx.stroke();
  ctx.fillStyle=cor;pts.forEach(p=>{ctx.beginPath();ctx.arc(p.x,p.y,2.5,0,Math.PI*2);ctx.fill();});
  ctx.fillStyle='#8b949e';ctx.font='9px IBM Plex Mono,monospace';ctx.textAlign='center';
  labels.forEach((l,i)=>ctx.fillText(l,pts[i].x,H-4));
}

function desenharDuplas(id,labels,v1,v2,c1,c2,l1,l2){
  const cv=resolveW(id);if(!cv)return;
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');ctx.clearRect(0,0,W,H);
  if(!v1||!v1.length)return;
  const max=Math.max(...v1,...v2)||1,pT=12,pB=24,pL=5,pR=10;
  const n=labels.length,slot=(W-pL-pR)/n,bw=Math.min(slot*.35,18),aH=H-pT-pB;
  [v1,v2].forEach((vs,gi)=>{vs.forEach((v,i)=>{const h=(v/max)*aH,x=pL+i*slot+gi*(bw+2)+slot*.12,y=H-pB-h;ctx.fillStyle=gi===0?c1:c2;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(x,y,bw,h,2);else ctx.rect(x,y,bw,h);ctx.fill();});});
  ctx.fillStyle='#8b949e';ctx.font='9px IBM Plex Mono,monospace';ctx.textAlign='center';
  labels.forEach((l,i)=>ctx.fillText(String(l).slice(0,8),pL+i*slot+slot/2,H-6));
  ctx.fillStyle=c1;ctx.fillRect(W-90,5,8,8);ctx.fillStyle='#8b949e';ctx.textAlign='left';ctx.font='8px IBM Plex Mono,monospace';ctx.fillText(l1,W-79,12);
  ctx.fillStyle=c2;ctx.fillRect(W-90,17,8,8);ctx.fillStyle='#8b949e';ctx.fillText(l2,W-79,24);
}

function desenharDonut(id,labels,vals,cores){
  const cv=resolveW(id);if(!cv)return;
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');ctx.clearRect(0,0,W,H);
  const tot=vals.reduce((a,b)=>a+b,0);if(!tot)return;
  const cx=H/2,cy=H/2,R=Math.min(H/2-6,36);
  let a=-Math.PI/2;
  vals.forEach((v,i)=>{const s=(v/tot)*Math.PI*2;ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,R,a,a+s);ctx.closePath();ctx.fillStyle=cores[i%cores.length];ctx.fill();a+=s;});
  ctx.fillStyle=getComputedStyle(cv.parentElement).backgroundColor||'#1c2333';
  ctx.beginPath();ctx.arc(cx,cy,R*.55,0,Math.PI*2);ctx.fill();
  const lx=H+6;ctx.font='9px IBM Plex Mono,monospace';ctx.textAlign='left';
  labels.forEach((lbl,i)=>{const y=cy-((labels.length-1)*13/2)+i*15;ctx.fillStyle=cores[i%cores.length];ctx.fillRect(lx,y-6,7,7);ctx.fillStyle='#8b949e';ctx.fillText(String(lbl).slice(0,9),lx+10,y+1);});
}

function desenharGauge(id,pct,cor){
  const cv=$(id);if(!cv)return;cv.width=160;cv.height=88;
  const ctx=cv.getContext('2d');ctx.clearRect(0,0,160,88);
  const cx=80,cy=80,R=60;
  ctx.beginPath();ctx.arc(cx,cy,R,Math.PI,2*Math.PI);ctx.lineWidth=11;ctx.strokeStyle='#21262d';ctx.stroke();
  const f=Math.PI+(pct/100)*Math.PI;
  ctx.beginPath();ctx.arc(cx,cy,R,Math.PI,f);ctx.strokeStyle=cor;ctx.lineCap='round';ctx.stroke();
}

function desenharSaldo(id,obras){
  const cv=resolveW(id);if(!cv)return;
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');ctx.clearRect(0,0,W,H);
  const items=obras.map(o=>({nome:tnome(o.nome),saldo:saldoObra(o.cod)})).sort((a,b)=>b.saldo-a.saldo);
  if(!items.length)return;
  const max=Math.max(...items.map(x=>Math.abs(x.saldo)))||1;
  const n=items.length,rowH=H/n,barH=Math.min(rowH*.55,16),lW=68,aW=W-lW-50;
  ctx.font='9px IBM Plex Mono,monospace';
  items.forEach((item,i)=>{
    const v=item.saldo,bw=(Math.abs(v)/max)*aW,y=i*rowH+(rowH-barH)/2;
    const cor=v>=0?'#3fb950':'#f85149';
    ctx.fillStyle='#e8edf5';ctx.beginPath();if(ctx.roundRect)ctx.roundRect(lW,y,aW,barH,2);else ctx.rect(lW,y,aW,barH);ctx.fill();
    ctx.fillStyle=cor;ctx.beginPath();if(ctx.roundRect)ctx.roundRect(lW,y,bw,barH,2);else ctx.rect(lW,y,bw,barH);ctx.fill();
    ctx.fillStyle='#8b949e';ctx.textAlign='right';ctx.fillText(item.nome.slice(0,12),lW-5,y+barH/2+3.5);
    ctx.fillStyle=cor;ctx.textAlign='left';ctx.fillText(fmtRK(v),lW+bw+4,y+barH/2+3.5);
  });
}

/* ══════════════════════════════════════════════
   OBRAS — novo layout full height com overlay
══════════════════════════════════════════════ */
function calcAvFis(o){
  const et=o.etapas||[];const tot=et.reduce((a,e)=>a+(e.peso||1),0);
  const ex=et.reduce((a,e)=>a+((e.peso||1)*(e.avancoFisico||0)/100),0);
  return tot>0?(ex/tot)*100:0;
}

let _obrasData=null,_drillOb=null;

function budgObra(cod){if(!_obrasData)return 0;return(_obrasData.budget||[]).filter(b=>b.obraCod===cod).reduce((s,b)=>s+(b.budgetAprov||0),0);}
function realObra(cod){if(!_obrasData)return 0;return(_obrasData.lancamentos||[]).filter(l=>l.obraCod===cod).reduce((s,l)=>s+l.qtd*l.precoUnit,0);}
function saldoObra(cod){return budgObra(cod)-realObra(cod);}

function renderObras(container,d){
  _obrasData=d;_drillOb=null;
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de obras carregado.<br><span style="font-size:10px">Selecione o arquivo no hub principal antes de abrir este painel.</span></div>';return;}
  container.style.cssText='';
container.innerHTML='<div class="obras-section"><div class="secao-titulo">Obras</div>'+buildObrasCards(d)+'</div>';
  setTimeout(()=>{
    drawMiniCard('total',d);
    drawMiniCard('andamento',d);
    drawMiniCard('concluidas',d);
    drawMiniCard('planejadas',d);
  },60);
}

function buildObrasCards(d){
  const obras=d.obras||[];
  const budget=d.budget||[];
  const lanc=d.lancamentos||[];
  const budgTotal=budget.reduce((s,b)=>s+(b.budgetAprov||0),0);
  const real=lanc.reduce((s,l)=>s+l.qtd*l.precoUnit,0);
  const saldo=budgTotal-real;
  const emAnd=obras.filter(o=>o.status==='Em Andamento');
  const conc=obras.filter(o=>o.status==='Concluído');
  const plan=obras.filter(o=>o.status==='Planejado');
  const avFis=obras.length?obras.reduce((s,o)=>s+calcAvFis(o),0)/obras.length:0;
  const planB=budget.filter(b=>plan.map(o=>o.cod).includes(b.obraCod)).reduce((s,b)=>s+(b.budgetAprov||0),0);

  return`<div class="obras-cards-grid" id="obras-grid">
    ${mkCard('total','TOTAL OBRAS',obras.length,'c-azul','#58a6ff',fmtRK(budgTotal)+' budget total',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Saldo</span><span class="ob-mini-val ${saldo<0?'c-vermelho':'c-verde'}">${fmtRK(saldo)}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">% Realizado</span><span class="ob-mini-val c-azul">${budgTotal>0?fmt(real/budgTotal*100,1):0}%</span></div>`)}
    ${mkCard('andamento','EM ANDAMENTO',emAnd.length,'c-laranja','#e3711a',fmt(avFis,1)+'% avanço médio',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Budget</span><span class="ob-mini-val c-azul">${fmtRK(emAnd.reduce((s,o)=>s+budgObra(o.cod),0))}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Realizado</span><span class="ob-mini-val c-laranja">${fmtRK(emAnd.reduce((s,o)=>s+realObra(o.cod),0))}</span></div>`)}
    ${mkCard('concluidas','CONCLUÍDAS',conc.length,'c-verde','#3fb950',obras.length>0?fmt(conc.length/obras.length*100,0)+'% do total':'—',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Gasto total</span><span class="ob-mini-val c-laranja">${fmtRK(conc.reduce((s,o)=>s+realObra(o.cod),0))}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Avg. avanço</span><span class="ob-mini-val c-verde">100%</span></div>`)}
    ${mkCard('planejadas','PLANEJADAS',plan.length,'c-azul','#a371f7',fmtRK(planB)+' previsto',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Budget prev.</span><span class="ob-mini-val c-azul">${fmtRK(planB)}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Prazo médio</span><span class="ob-mini-val c-azul">${prazoMedio(plan)}</span></div>`)}
  </div>`;
}

function mkCard(tipo,label,val,valCls,accent,sub,statsHtml){
  return`<div class="ob-card" id="ob-card-${tipo}" onclick="toggleObCard('${tipo}')">
    <div class="ob-card-head">
      <div class="ob-card-accent" style="background:${accent}"></div>
      <div class="ob-card-label">${label}</div>
      <div class="ob-card-val ${valCls}">${val||'—'}</div>
      <div class="ob-card-sub">${sub}</div>
    </div>
    <div class="ob-card-body">
      <div class="ob-chart-wrap"><canvas id="cv-mini-${tipo}"></canvas></div>
      <div class="ob-leg" id="ob-leg-${tipo}"></div>
      <div style="flex:1"></div>
      <div class="ob-leg-sep"></div>
      ${statsHtml}
      <div class="ob-card-hint">▼ ver análise gerencial</div>
    </div>
  </div>`;
}

function prazoMedio(obras){
  const hoje=new Date();
  const com=obras.filter(o=>o.dtFimPrev);
  if(!com.length)return'—';
  const med=com.reduce((s,o)=>s+Math.floor((new Date(o.dtFimPrev+'T00:00:00')-hoje)/86400000),0)/com.length;
  return med<0?'Atrasado':Math.round(med)+'d';
}
function drawMiniCard(tipo,d){
  const obras=d.obras||[];
  const lanc=d.lancamentos||[];
  const cv=document.getElementById('cv-mini-'+tipo);
  if(!cv)return;
  cv.width=140;cv.height=140;

  let labels=[],vals=[],cores=[];
  if(tipo==='total'){
    const sm={};obras.forEach(o=>{sm[o.status]=(sm[o.status]||0)+1;});
    const sl=Object.entries(sm).filter(x=>x[1]);
    labels=sl.map(x=>x[0]);vals=sl.map(x=>x[1]);
    cores=['#e3711a','#3fb950','#58a6ff','#f85149'];
  } else if(tipo==='andamento'){
    const lista=obras.filter(o=>o.status==='Em Andamento');
    if(!lista.length)return;
    labels=lista.map(o=>tnome(o.nome));
    vals=lista.map(o=>Math.max(calcAvFis(o),1));
    cores=['#e3711a','#d29922','#58a6ff','#a371f7','#3fb950'];
  } else if(tipo==='concluidas'){
    const lista=obras.filter(o=>o.status==='Concluído');
    if(!lista.length)return;
    const catM={};lista.forEach(o=>{lanc.filter(l=>l.obraCod===o.cod).forEach(l=>{const c=l.categoria||'Outros';catM[c]=(catM[c]||0)+l.qtd*l.precoUnit;});});
    const top=Object.entries(catM).sort((a,b)=>b[1]-a[1]).slice(0,5);
    if(!top.length){labels=['Concluídas'];vals=[lista.length];}
    else{labels=top.map(x=>x[0]);vals=top.map(x=>x[1]);}
    cores=['#3fb950','#58a6ff','#d29922','#a371f7','#e3711a'];
  } else if(tipo==='planejadas'){
    const lista=obras.filter(o=>o.status==='Planejado');
    if(!lista.length)return;
    labels=lista.map(o=>tnome(o.nome));
    vals=lista.map(o=>Math.max(budgObra(o.cod),1));
    cores=['#a371f7','#58a6ff','#2E5FA3','#e3711a','#d29922'];
  }

  desenharDonutResponsivo(cv,labels,vals,cores);

  const tot=vals.reduce((a,b)=>a+b,0);
  const usarValor=(tipo==='total'||tipo==='andamento'||tipo==='planejadas');
  let leg=document.getElementById('ob-leg-'+tipo);
  if(!leg){
    leg=document.createElement('div');
    leg.className='ob-leg';
    cv.parentElement.after(leg);
  }
  const maxLeg=4;
  const temMais=labels.length>maxLeg;
  leg.innerHTML=labels.slice(0,maxLeg).map((l,i)=>{
    const v=usarValor?Math.round(vals[i]):Math.round(vals[i]/tot*100)+'%';
    return`<div class="ob-leg-item">
      <span class="ob-leg-dot" style="background:${cores[i%cores.length]}"></span>
      <span class="ob-leg-txt">${l}</span>
      <span class="ob-leg-val">${v}</span>
    </div>`;
  }).join('')+(temMais?`<div class="ob-leg-mais" onclick="expandirLegenda(event,'${tipo}')" data-labels='${JSON.stringify(labels)}' data-vals='${JSON.stringify(vals)}' data-cores='${JSON.stringify(cores)}' data-usarvalor='${usarValor}'>+ ${labels.length-maxLeg} mais ▼</div>`:'');
}

function desenharDonutResponsivo(cv,labels,vals,cores){
  const W=cv.width,H=cv.height,ctx=cv.getContext('2d');
  ctx.clearRect(0,0,W,H);
  const tot=vals.reduce((a,b)=>a+b,0);if(!tot)return;
  const R=Math.min(W,H)/2-6;
  const cx=W/2,cy=H/2;
  let ang=-Math.PI/2;
  vals.forEach((v,i)=>{
    const s=(v/tot)*Math.PI*2;
    ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,R,ang,ang+s);ctx.closePath();
    ctx.fillStyle=cores[i%cores.length];ctx.fill();
    ang+=s;
  });
  ctx.fillStyle='#ffffff';
  ctx.beginPath();ctx.arc(cx,cy,R*.52,0,Math.PI*2);ctx.fill();
  const lblC=vals.reduce((a,b)=>a+b,0);
  const txt=lblC>999?fmtRK(lblC):String(Math.round(lblC));
  ctx.fillStyle='#0f1c3f';
  ctx.font='bold 13px IBM Plex Mono,monospace';
  ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.fillText(txt,cx,cy);
}
function desenharDonutSVG(containerId,labels,vals,cores){
  const wrap=document.getElementById(containerId);
  if(!wrap)return;
  const tot=vals.reduce((a,b)=>a+b,0);if(!tot)return;
  const R=40,r=22,cx=50,cy=50;
  let paths='',a=-Math.PI/2;
  vals.forEach((v,i)=>{
    const s=(v/tot)*Math.PI*2;
    const x1=cx+R*Math.cos(a),y1=cy+R*Math.sin(a);
    const a2=a+s;
    const x2=cx+R*Math.cos(a2),y2=cy+R*Math.sin(a2);
    const large=s>Math.PI?1:0;
    const xi1=cx+r*Math.cos(a),yi1=cy+r*Math.sin(a);
    const xi2=cx+r*Math.cos(a2),yi2=cy+r*Math.sin(a2);
    paths+=`<path d="M${x1},${y1} A${R},${R} 0 ${large},1 ${x2},${y2} L${xi2},${yi2} A${r},${r} 0 ${large},0 ${xi1},${yi1} Z" fill="${cores[i%cores.length]}"/>`;
    a+=s;
  });
  const legItems=labels.slice(0,5).map((l,i)=>{
    const pct=Math.round(vals[i]/tot*100);
    const txt=String(l).length>14?String(l).slice(0,13)+'…':String(l);
    return`<div class="donut-leg-item">
  <span class="donut-leg-dot" style="background:${cores[i%cores.length]}"></span>
  <span class="donut-leg-txt">${txt}</span>
  <span class="donut-leg-pct">${pct}%</span>
</div>`;
  }).join('');
  wrap.innerHTML=`
    <div class="donut-wrap">
      <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
        ${paths}
        <text x="50" y="54" text-anchor="middle" font-size="13" font-weight="700" font-family="IBM Plex Mono,monospace" fill="#0f1c3f">${tot>999999?fmtRK(tot):tot>999?(tot/1000).toFixed(1)+'k':String(Math.round(tot))}</text>
      </svg>
    </div>
    <div class="donut-leg">${legItems}</div>`;
}

function toggleObCard(tipo){
  const existing=document.getElementById('ob-overlay');
  if(existing){
    existing.remove();
    if(_drillOb===tipo){_drillOb=null;return;}
  }
  _drillOb=tipo;
  if(!_obrasData)return;
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo)return;
  const overlay=document.createElement('div');
  overlay.className='ob-overlay';
  overlay.id='ob-overlay';
  overlay.innerHTML=buildOverlayHTML(tipo,_obrasData);
  conteudo.innerHTML='';
  conteudo.style.cssText='flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden';
  conteudo.appendChild(overlay);
  setTimeout(()=>drawOverlayCharts(tipo,_obrasData),60);
}

function buildOverlayHTML(tipo,d){
  const obras=d.obras||[];const lanc=d.lancamentos||[];const hoje=new Date();
  const filtros={total:obras,andamento:obras.filter(o=>o.status==='Em Andamento'),concluidas:obras.filter(o=>o.status==='Concluído'),planejadas:obras.filter(o=>o.status==='Planejado')};
  const titulos={total:'Todas as Obras',andamento:'Em Andamento',concluidas:'Concluídas',planejadas:'Planejadas'};
  const lista=filtros[tipo]||[];
  const totalB=lista.reduce((s,o)=>s+budgObra(o.cod),0);
  const totalR=lista.reduce((s,o)=>s+realObra(o.cod),0);
  const saldo=totalB-totalR;
  const avgFis=lista.length?lista.reduce((s,o)=>s+calcAvFis(o),0)/lista.length:0;
  const pctRe=totalB>0?(totalR/totalB)*100:0;

  const pb=(v,c)=>`<div class="ob-mini-prog"><div class="ob-mbar"><div class="ob-mfill" style="width:${Math.min(v,100)}%;background:${c}"></div></div><span style="font-size:9px;font-family:var(--mono);color:var(--text-muted);min-width:30px">${fmt(v,1)}%</span></div>`;
  const badgeSt=s=>{const m={'Em Andamento':'badge-and','Concluído':'badge-conc','Planejado':'badge-plan','Suspenso':'badge-susp'};return`<span class="badge-sm ${m[s]||'badge-plan'}">${s}</span>`;};

  const linhas=lista.map(o=>{
    const b=budgObra(o.cod),r=realObra(o.cod),af=calcAvFis(o),pf=b>0?(r/b)*100:0;
    const prazo=o.dtFimPrev?Math.floor((new Date(o.dtFimPrev+'T00:00:00')-hoje)/86400000):null;
    const corP=prazo===null?'var(--text-dim)':prazo<0?'var(--red)':prazo<=30?'var(--yellow)':'var(--green)';
    return`<tr style="cursor:pointer" onclick="abrirDetalheObra('${o.cod}')" title="Ver detalhes de ${o.nome}">
  <td style="font-weight:500;max-width:130px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${o.nome}">${tnome(o.nome)}</td>
  <td>${badgeSt(o.status)}</td>
  <td>${pb(af,'#58a6ff')}</td>
  <td>${pb(pf,pf>85?'#f85149':pf>60?'#d29922':'#3fb950')}</td>
  <td style="font-family:var(--mono);font-size:10px;color:${b-r<0?'var(--red)':'var(--green)'}">${fmtRK(b-r)}</td>
  <td style="font-family:var(--mono);font-size:10px;color:${corP}">${prazo===null?'—':prazo<0?'Atrasado':prazo+'d'}</td>
  <td style="color:var(--blue-light);font-size:11px">›</td>
</tr>`;
  }).join('');

  return`
  <div class="ob-ov-header">
    <div class="ob-ov-title">${titulos[tipo]} &mdash; Análise Gerencial (${lista.length} obras)</div>
    <button class="ob-ov-close" onclick="voltarParaSubCards()">← voltar</button>
  </div>
  <div class="ob-ov-kpis">
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Budget Total</div><div class="ob-ov-kpi-val c-azul">${fmtRK(totalB)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Realizado</div><div class="ob-ov-kpi-val c-laranja">${fmtRK(totalR)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Saldo</div><div class="ob-ov-kpi-val ${saldo<0?'c-vermelho':'c-verde'}">${fmtRK(saldo)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Avanço Físico Médio</div><div class="ob-ov-kpi-val ${avgFis>70?'c-verde':avgFis>40?'c-amarelo':'c-laranja'}">${fmt(avgFis,1)}%</div></div>
  </div>
  <div class="ob-ov-charts">
    <div class="ob-ov-cbox">
      <div class="ob-ov-ctit">Distribuição de Status</div>
      <canvas id="cv-ov-pizza1" width="190" height="140" style="width:190px;height:140px;display:block"></canvas>
    </div>
    <div class="ob-ov-cbox">
      <div class="ob-ov-ctit">Budget vs Realizado</div>
      <canvas id="cv-ov-pizza2" width="190" height="140" style="width:190px;height:140px;display:block"></canvas>
    </div>
    <div class="ob-ov-cbox" style="flex:1">
      <div class="ob-ov-ctit">Gastos por Categoria</div>
      <canvas id="cv-ov-barras" width="500" height="140" style="width:100%;height:140px;display:block"></canvas>
    </div>
  </div>
  <div class="ob-ov-tbox">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Detalhamento das ${lista.length} obra(s)</div>
    <table class="ob-ov-table">
      <thead><tr><th>Obra</th><th>Status</th><th>% Físico</th><th>% Financeiro</th><th>Saldo</th><th>Prazo</th><th></th></tr></thead>
      <tbody>${linhas||'<tr><td colspan="6" style="text-align:center;color:var(--text-dim);padding:16px">Nenhuma obra</td></tr>'}</tbody>
    </table>
  </div>`;
}

function drawOverlayCharts(tipo,d){
  const obras=d.obras||[];const lanc=d.lancamentos||[];
  const filtros={total:obras,andamento:obras.filter(o=>o.status==='Em Andamento'),concluidas:obras.filter(o=>o.status==='Concluído'),planejadas:obras.filter(o=>o.status==='Planejado')};
  const lista=filtros[tipo]||[];
  const sm={};(tipo==='total'?obras:lista).forEach(o=>{sm[o.status]=(sm[o.status]||0)+1;});
  const sl=Object.entries(sm);
  if(sl.length){
    const cv1=document.getElementById('cv-ov-pizza1');
    if(cv1)desenharDonutResponsivo(cv1,sl.map(x=>x[0]),sl.map(x=>x[1]),['#e3711a','#3fb950','#58a6ff','#f85149','#d29922']);
  }
  const totalB=lista.reduce((s,o)=>s+budgObra(o.cod),0);
  const totalR=lista.reduce((s,o)=>s+realObra(o.cod),0);
  const saldo=Math.max(totalB-totalR,0);
  const cv2=document.getElementById('cv-ov-pizza2');
  if(cv2&&(totalR||saldo))desenharDonutResponsivo(cv2,['Realizado','Saldo'],[totalR||1,saldo||1],['#e3711a','#2E5FA3']);
  const catM={};lista.forEach(o=>{lanc.filter(l=>l.obraCod===o.cod).forEach(l=>{const c=l.categoria||'Outros';catM[c]=(catM[c]||0)+l.qtd*l.precoUnit;});});
  const top=Object.entries(catM).sort((a,b)=>b[1]-a[1]).slice(0,8);
  const cvb=document.getElementById('cv-ov-barras');
  if(cvb&&top.length){
    const pw=cvb.parentElement.clientWidth||400;cvb.width=pw;
    desenharBarrasH('cv-ov-barras',top.map(x=>x[0]),top.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7','#58a6ff','#f85149','#8b949e']);
  }
}
function abrirDetalheObra(cod){
  if(!_obrasData)return;
  const o=(_obrasData.obras||[]).find(x=>x.cod===cod);
  if(!o)return;

  const b=budgObra(cod),r=realObra(cod),af=calcAvFis(o),pf=b>0?(r/b)*100:0,ef=af-pf;
  const lancsObra=(_obrasData.lancamentos||[]).filter(l=>l.obraCod===cod);
  const mensal={};lancsObra.forEach(l=>{const m=l.dtLanc?l.dtLanc.slice(0,7):'';if(m)mensal[m]=(mensal[m]||0)+l.qtd*l.precoUnit;});
  const mKeys=Object.keys(mensal).sort().slice(-8);
  const catMap={};lancsObra.forEach(l=>{const c=l.categoria||'Outros';catMap[c]=(catMap[c]||0)+l.qtd*l.precoUnit;});
  const topCat=Object.entries(catMap).sort((a,b2)=>b2[1]-a[1]).slice(0,5);
  const etapas=o.etapas||[];
  const hoje=new Date();
  const prazo=o.dtFimPrev?Math.floor((new Date(o.dtFimPrev+'T00:00:00')-hoje)/86400000):null;
  const corP=prazo===null?'var(--text-dim)':prazo<0?'var(--red)':prazo<=30?'var(--yellow)':'var(--green)';
  const pb2=(v,c)=>`<div class="ob-mini-prog"><div class="ob-mbar"><div class="ob-mfill" style="width:${Math.min(v,100)}%;background:${c}"></div></div><span style="font-size:9px;font-family:var(--mono);color:var(--text-muted);min-width:34px">${fmt(v,1)}%</span></div>`;
  const badgeSt=s=>{const m={'Em Andamento':'badge-and','Concluído':'badge-conc','Planejado':'badge-plan','Suspenso':'badge-susp'};return`<span class="badge-sm ${m[s]||'badge-plan'}">${s}</span>`;};

  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo)return;

  conteudo.innerHTML=`
  <div class="ob-ov-header">
    <div class="ob-ov-title">${o.nome} — Detalhamento</div>
    <div style="display:flex;gap:8px">
      <button class="ob-ov-close" onclick="voltarParaLista()">← voltar</button>
    </div>
  </div>

  <div class="ob-ov-kpis" style="margin-bottom:12px">
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Budget</div><div class="ob-ov-kpi-val c-azul">${fmtRK(b)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Realizado</div><div class="ob-ov-kpi-val c-laranja">${fmtRK(r)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Saldo</div><div class="ob-ov-kpi-val ${b-r<0?'c-vermelho':'c-verde'}">${fmtRK(b-r)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Eficiência</div><div class="ob-ov-kpi-val ${ef>5?'c-verde':ef<-5?'c-vermelho':'c-amarelo'}">${ef>=0?'+':''}${fmt(ef,1)}%</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Status</div><div class="ob-ov-kpi-val" style="font-size:13px">${badgeSt(o.status)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Prazo</div><div class="ob-ov-kpi-val" style="font-size:16px;color:${corP}">${prazo===null?'—':prazo<0?'Atrasado':prazo+'d'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Avanço Físico</div><div class="ob-ov-kpi-val ${af>70?'c-verde':af>40?'c-amarelo':'c-laranja'}">${fmt(af,1)}%</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">% Financeiro</div><div class="ob-ov-kpi-val c-azul">${fmt(pf,1)}%</div></div>
  </div>

  <div class="ob-ov-charts" style="margin-bottom:12px">
    <div class="ob-ov-cbox">
      <div class="ob-ov-ctit">Gastos mensais</div>
      <canvas id="cv-det-spark" width="300" height="140" style="width:100%;height:140px;display:block"></canvas>
    </div>
    <div class="ob-ov-cbox" style="flex:1">
      <div class="ob-ov-ctit">Por categoria</div>
      <canvas id="cv-det-cat" width="500" height="140" style="width:100%;height:140px;display:block"></canvas>
    </div>
  </div>

  ${etapas.length?`
  <div class="ob-ov-tbox" style="margin-bottom:12px">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Etapas</div>
    <table class="ob-ov-table">
      <thead><tr><th>Etapa</th><th>Peso</th><th>Avanço Físico</th></tr></thead>
      <tbody>${etapas.map(e=>`<tr>
        <td>${e.nome||e.descricao||'—'}</td>
        <td style="font-family:var(--mono);font-size:10px">${e.peso||1}</td>
        <td>${pb2(e.avancoFisico||0,'#58a6ff')}</td>
      </tr>`).join('')}</tbody>
    </table>
  </div>`:''}

  ${lancsObra.length?`
  <div class="ob-ov-tbox">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Últimos lançamentos</div>
    <table class="ob-ov-table">
      <thead><tr><th>Data</th><th>Categoria</th><th>Fornecedor</th><th>Total</th></tr></thead>
      <tbody>${lancsObra.slice().sort((a,b2)=>(b2.dtLanc||'').localeCompare(a.dtLanc||'')).slice(0,10).map(l=>`<tr>
        <td style="font-family:var(--mono);font-size:10px">${l.dtLanc?l.dtLanc.split('-').reverse().join('/'):'—'}</td>
        <td>${l.categoria||'—'}</td>
        <td>${l.fornecedor||'—'}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--blue-light)">${fmtRK(l.qtd*l.precoUnit)}</td>
      </tr>`).join('')}</tbody>
    </table>
  </div>`:''}`;

  requestAnimationFrame(()=>{
    if(mKeys.length>=2){
      const cvspark=document.getElementById('cv-det-spark');
      if(cvspark){const pw=cvspark.parentElement.clientWidth||300;cvspark.width=pw;desenharSpark('cv-det-spark',mKeys.map(k=>k.slice(5)),mKeys.map(k=>mensal[k]),'#58a6ff');}
    }
    if(topCat.length){
      const cvcat=document.getElementById('cv-det-cat');
      if(cvcat){const pw=cvcat.parentElement.clientWidth||400;cvcat.width=pw;desenharBarrasH('cv-det-cat',topCat.map(x=>x[0]),topCat.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7']);}
    }
  });
}
/* ══════════════════════════════════════════════
   ATIVIDADES
══════════════════════════════════════════════ */
function renderAtividades(container,d){
  const ativs=Array.isArray(d)?d:(Array.isArray(d?.atividades)?d.atividades:[]);
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de atividades carregado.<br><span style="font-size:10px">Selecione o arquivo no hub principal.</span></div>';return;}
  const hoje=new Date().toISOString().slice(0,10);
  const total=ativs.length;
  const done=ativs.filter(a=>a.status==='done').length;
  const venc=ativs.filter(a=>a.prazo&&a.prazo<hoje&&a.status!=='done').length;
  const semResp=ativs.filter(a=>!a.responsavel&&!a.assignee).length;
  const doing=ativs.filter(a=>a.status==='doing').length;
  const blocked=ativs.filter(a=>a.status==='blocked').length;
  const todo=ativs.filter(a=>!a.status||a.status==='todo').length;
  const pct=total>0?Math.round(done/total*100):0;
  const statusMap={};ativs.forEach(a=>{const s=a.status||'todo';statusMap[s]=(statusMap[s]||0)+1;});
  const prioMap={};ativs.forEach(a=>{const p=a.prioridade||a.priority||'Normal';prioMap[p]=(prioMap[p]||0)+1;});
  const respMap={};ativs.forEach(a=>{const r=a.responsavel||a.assignee||'';if(r)respMap[r]=(respMap[r]||0)+1;});
  const topResp=Object.entries(respMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const mensal={};ativs.forEach(a=>{const m=(a.criadoEm||a.createdAt||'').slice(0,7);if(m)mensal[m]=(mensal[m]||0)+1;});
  const mKeys=Object.keys(mensal).sort().slice(-6);

  // guarda dados globais para o overlay
  window._ativsData={ativs,statusMap,prioMap,topResp,mensal,mKeys,hoje};
  window._ativDrill=null;

  container.innerHTML=`<div class="mod-section">
    <div class="secao-titulo">Atividades</div>
    <div class="mod-cards-grid" id="ativs-grid">
      ${mkModCard('at-total','TOTAL TAREFAS',total,'c-azul','#58a6ff',`${total-done} em aberto`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Concluídas</span><span class="ob-mini-val c-verde">${done}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">% Concluído</span><span class="ob-mini-val c-azul">${pct}%</span></div>`)}
      ${mkModCard('at-venc','VENCIDAS',venc,venc>0?'c-vermelho':'c-verde','#f85149','fora do prazo',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Em andamento</span><span class="ob-mini-val c-laranja">${doing}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Bloqueadas</span><span class="ob-mini-val c-vermelho">${blocked}</span></div>`)}
      ${mkModCard('at-sem','SEM RESPONSÁVEL',semResp,semResp>0?'c-amarelo':'c-verde','#d29922','atribuição pendente',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">A fazer</span><span class="ob-mini-val c-azul">${todo}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Top resp.</span><span class="ob-mini-val c-azul">${topResp[0]?topResp[0][0]:'—'}</span></div>`)}
      ${mkModCard('at-done','CONCLUÍDAS',done,'c-verde','#3fb950',`${pct}% do total`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Nos últimos</span><span class="ob-mini-val c-verde">${mKeys.length} meses</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Bloqueadas</span><span class="ob-mini-val c-vermelho">${blocked}</span></div>`)}
    </div>
  </div>`;

  setTimeout(()=>{
    // total → pizza de status
    const sl=Object.entries(statusMap).filter(x=>x[1]);
    drawModMiniCard('cv-mod-at-total',sl.map(x=>x[0]),sl.map(x=>x[1]),['#58a6ff','#e3711a','#3fb950','#f85149','#d29922']);
    // vencidas → pizza de prioridade
    const pl=Object.entries(prioMap).filter(x=>x[1]);
    drawModMiniCard('cv-mod-at-venc',pl.map(x=>x[0]),pl.map(x=>x[1]),['#f85149','#d29922','#3fb950','#58a6ff']);
    // sem resp → pizza por responsável (top)
    drawModMiniCard('cv-mod-at-sem',topResp.map(x=>x[0]),topResp.map(x=>x[1]),['#2E5FA3','#a371f7','#3fb950','#d29922','#e3711a']);
    // concluídas → pizza por mês
    drawModMiniCard('cv-mod-at-done',mKeys.map(k=>k.slice(5)),mKeys.map(k=>mensal[k]),['#3fb950','#58a6ff','#2E5FA3','#a371f7','#d29922','#e3711a']);
  },60);
}

/* ══════════════════════════════════════════════
   CHAMADOS
══════════════════════════════════════════════ */
function renderChamados(container,d){
  const cham=d?.chamados||(Array.isArray(d)?d:[]);
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de chamados carregado.<br><span style="font-size:10px">Selecione o arquivo no hub principal.</span></div>';return;}
  const total=cham.length;
  const abertos=cham.filter(c=>c.status==='Aberto').length;
  const emAt=cham.filter(c=>c.status==='Em Andamento'||c.status==='Em Atendimento').length;
  const alta=cham.filter(c=>c.prioridade==='Alta'||c.prioridade==='Crítica').length;
  const semResp=cham.filter(c=>!c.responsavel&&!c.atendente).length;
  const resolvidos=cham.filter(c=>c.status==='Resolvido'||c.status==='Fechado'||c.status==='Concluído').length;
  const pct=total>0?Math.round(resolvidos/total*100):0;
  const statusMap={};cham.forEach(c=>{const s=c.status||'Aberto';statusMap[s]=(statusMap[s]||0)+1;});
  const catMap={};cham.forEach(c=>{const cat=c.categoria||'Geral';catMap[cat]=(catMap[cat]||0)+1;});
  const topCat=Object.entries(catMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const respMap={};cham.forEach(c=>{const r=c.responsavel||c.atendente||'';if(r)respMap[r]=(respMap[r]||0)+1;});
  const topResp=Object.entries(respMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const prioMap={};cham.forEach(c=>{const p=c.prioridade||'Média';prioMap[p]=(prioMap[p]||0)+1;});
  const mensal={};cham.forEach(c=>{const m=(c.dtAbertura||c.criadoEm||'').slice(0,7);if(m)mensal[m]=(mensal[m]||0)+1;});
  const mKeys=Object.keys(mensal).sort().slice(-6);

  document.querySelectorAll('#cham-grid .ob-card').forEach(card=>{
    const id=card.id.replace('ob-card-ch-','ch-');
    card.style.cursor='pointer';
    card.addEventListener('click',()=>abrirDrillChamados(id));
  });
  window._chamData={cham,statusMap,catMap,topCat,respMap,topResp,prioMap,mensal,mKeys};
  window._chamDrill=null;

  container.innerHTML=`<div class="mod-section">
    <div class="secao-titulo">Chamados</div>
    <div class="mod-cards-grid" id="cham-grid">
      ${mkModCard('ch-total','TOTAL CHAMADOS',total,'c-azul','#58a6ff',`${abertos} abertos`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Em atendimento</span><span class="ob-mini-val c-laranja">${emAt}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Resolvidos</span><span class="ob-mini-val c-verde">${resolvidos}</span></div>`)}
      ${mkModCard('ch-alta','ALTA PRIORIDADE',alta,alta>0?'c-vermelho':'c-verde','#f85149',`${emAt} em atendimento`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Críticos</span><span class="ob-mini-val c-vermelho">${cham.filter(c=>c.prioridade==='Crítica').length}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Abertos alta</span><span class="ob-mini-val c-laranja">${cham.filter(c=>(c.prioridade==='Alta'||c.prioridade==='Crítica')&&c.status==='Aberto').length}</span></div>`)}
      ${mkModCard('ch-sem','SEM RESPONSÁVEL',semResp,semResp>0?'c-amarelo':'c-verde','#d29922','atribuição pendente',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Top categ.</span><span class="ob-mini-val c-azul">${topCat[0]?topCat[0][0]:'—'}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Top atend.</span><span class="ob-mini-val c-azul">${topResp[0]?topResp[0][0]:'—'}</span></div>`)}
      ${mkModCard('ch-resol','RESOLVIDOS',resolvidos,'c-verde','#3fb950',`${pct}% do total`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Taxa resolução</span><span class="ob-mini-val c-verde">${pct}%</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Pendentes</span><span class="ob-mini-val c-amarelo">${total-resolvidos}</span></div>`)}
    </div>
  </div>`;

  setTimeout(()=>{
    const sl=Object.entries(statusMap).filter(x=>x[1]);
    drawModMiniCard('cv-mod-ch-total',sl.map(x=>x[0]),sl.map(x=>x[1]),['#f85149','#e3711a','#3fb950','#58a6ff']);
    const pl=Object.entries(prioMap).filter(x=>x[1]);
    drawModMiniCard('cv-mod-ch-alta',pl.map(x=>x[0]),pl.map(x=>x[1]),['#f85149','#e3711a','#d29922','#3fb950']);
    drawModMiniCard('cv-mod-ch-sem',topCat.map(x=>x[0]),topCat.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7']);
    drawModMiniCard('cv-mod-ch-resol',mKeys.map(k=>k.slice(5)),mKeys.map(k=>mensal[k]),['#3fb950','#58a6ff','#2E5FA3','#d29922','#e3711a','#a371f7']);
  },60);
const slaKey = 'chamados-sla-config';
const slaCfg = (() => { try { return JSON.parse(localStorage.getItem(slaKey))||{}; } catch(e){return{};} })();
const slaMap  = {'Crítica':1,'Alta':3,'Média':5,'Baixa':7};
function _sla(p){ return slaCfg[p]||slaMap[p]||7; }
function _dias(c){ const i=new Date(c.dtAbertura||c.dataAbertura||c.criadoEm||Date.now()); const f=c.dataConclusao?new Date(c.dataConclusao):new Date(); return Math.max(0,(f-i)/86400000); }
const comData = cham.filter(x=>x.dtAbertura||x.dataAbertura||x.criadoEm);
const noSLA   = comData.filter(c=>_dias(c)<=_sla(c.prioridade)).length;
const pctSLA  = comData.length ? Math.round(noSLA/comData.length*100) : 100;
const corSLA  = pctSLA>=90?'c-verde':pctSLA>=70?'c-amarelo':'c-vermelho';
document.getElementById('mfoot-chamados').textContent =
  Math.round(resolvidos/Math.max(total,1)*100)+'% resolvidos · SLA: '+pctSLA+'%';
}
let _chamDrillAtivo=null;

function abrirDrillChamados(tipo){
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo||!window._chamData)return;
  _chamDrillAtivo=tipo;
  conteudo.style.cssText='flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden';
  const overlay=document.createElement('div');
  overlay.className='ob-overlay';
  overlay.id='ch-overlay';
  overlay.innerHTML=buildDrillChamados(tipo);
  conteudo.innerHTML='';
  conteudo.appendChild(overlay);
  setTimeout(()=>drawDrillChamadosCharts(tipo),60);
}

function buildDrillChamados(tipo){
  const {cham,statusMap,prioMap,topCat,topResp,mensal,mKeys}=window._chamData;
  const titulos={
    'ch-total':'Todos os Chamados',
    'ch-alta':'Alta Prioridade',
    'ch-sem':'Sem Responsável',
    'ch-resol':'Resolvidos'
  };
  const filtros={
    'ch-total':cham,
    'ch-alta':cham.filter(c=>c.prioridade==='Alta'||c.prioridade==='Crítica'),
    'ch-sem':cham.filter(c=>!c.responsavel&&!c.atendente),
    'ch-resol':cham.filter(c=>['Resolvido','Fechado','Concluído'].includes(c.status))
  };
  const lista=filtros[tipo]||cham;
  const total=lista.length;
  const abertos=lista.filter(c=>c.status==='Aberto').length;
  const emAt=lista.filter(c=>c.status==='Em Andamento'||c.status==='Em Atendimento').length;
  const resolvidos=lista.filter(c=>['Resolvido','Fechado','Concluído'].includes(c.status)).length;
  const pct=total>0?Math.round(resolvidos/total*100):0;
  const badgePrio=p=>{const m={'Alta':'badge-and','Crítica':'badge-susp','Média':'badge-plan','Baixa':'badge-conc'};return`<span class="badge-sm ${m[p]||'badge-plan'}">${p||'—'}</span>`;};
  const badgeSt=s=>{const m={'Aberto':'badge-and','Em Andamento':'badge-plan','Resolvido':'badge-conc','Fechado':'badge-conc','Concluído':'badge-conc','Cancelado':'badge-susp'};return`<span class="badge-sm ${m[s]||'badge-plan'}">${s||'—'}</span>`;};
  const linhas=lista.slice().sort((a,b)=>{
    const ord={'Aberto':0,'Em Andamento':1,'Crítica':0,'Alta':1,'Média':2,'Baixa':3};
    return(ord[a.status]??9)-(ord[b.status]??9)||(ord[a.prioridade]??9)-(ord[b.prioridade]??9);
  }).slice(0,50).map(c=>`<tr style="cursor:pointer" onclick="abrirDetalheChamado('${c.id}')">
    <td style="font-family:var(--mono);font-size:10px;color:var(--blue-light)">${c.id||'—'}</td>
    <td style="max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="${c.titulo||''}">${c.titulo||'—'}</td>
    <td>${badgeSt(c.status)}</td>
    <td>${badgePrio(c.prioridade)}</td>
    <td style="font-size:10px;color:var(--text-muted)">${c.categoria||'—'}</td>
    <td style="font-size:10px;color:${c.responsavel?'var(--text)':'var(--red)'}">${c.responsavel||c.atendente||'⚠ sem resp.'}</td>
    <td style="font-family:var(--mono);font-size:10px;color:var(--text-muted)">${c.dtAbertura||c.dataAbertura||c.criadoEm?((c.dtAbertura||c.dataAbertura||c.criadoEm).slice(0,10).split('-').reverse().join('/')):'—'}</td>
    <td style="color:var(--blue-light);font-size:11px">›</td>
  </tr>`).join('');

  return`
  <div class="ob-ov-header">
    <div class="ob-ov-title">${titulos[tipo]||'Chamados'} — Análise (${total})</div>
    <button class="ob-ov-close" onclick="voltarParaChamados()">← voltar</button>
  </div>
  <div class="ob-ov-kpis">
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Total</div><div class="ob-ov-kpi-val c-azul">${total}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Abertos</div><div class="ob-ov-kpi-val ${abertos>0?'c-vermelho':'c-verde'}">${abertos}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Em atendimento</div><div class="ob-ov-kpi-val c-laranja">${emAt}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Resolvidos</div><div class="ob-ov-kpi-val c-verde">${resolvidos}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Taxa resolução</div><div class="ob-ov-kpi-val ${pct>70?'c-verde':pct>40?'c-amarelo':'c-vermelho'}">${pct}%</div></div>
  </div>
  <div class="ob-ov-charts">
    <div class="ob-ov-cbox">
      <div class="ob-ov-ctit">Status</div>
      <canvas id="cv-ch-ov-status" width="190" height="140" style="width:190px;height:140px;display:block"></canvas>
    </div>
    <div class="ob-ov-cbox">
      <div class="ob-ov-ctit">Prioridade</div>
      <canvas id="cv-ch-ov-prio" width="190" height="140" style="width:190px;height:140px;display:block"></canvas>
    </div>
    <div class="ob-ov-cbox" style="flex:1">
      <div class="ob-ov-ctit">Por categoria</div>
      <canvas id="cv-ch-ov-cat" width="400" height="140" style="width:100%;height:140px;display:block"></canvas>
    </div>
  </div>
  <div class="ob-ov-tbox">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Chamados (${Math.min(total,50)}${total>50?' de '+total:''})</div>
    <table class="ob-ov-table">
      <thead><tr><th>ID</th><th>Título</th><th>Status</th><th>Prioridade</th><th>Categoria</th><th>Responsável</th><th>Abertura</th><th></th></tr></thead>
      <tbody>${linhas||'<tr><td colspan="8" style="text-align:center;color:var(--text-dim);padding:16px">Nenhum chamado</td></tr>'}</tbody>
    </table>
  </div>`;
}

function drawDrillChamadosCharts(tipo){
  const {cham,statusMap,prioMap,topCat}=window._chamData;
  const filtros={
    'ch-total':cham,
    'ch-alta':cham.filter(c=>c.prioridade==='Alta'||c.prioridade==='Crítica'),
    'ch-sem':cham.filter(c=>!c.responsavel&&!c.atendente),
    'ch-resol':cham.filter(c=>['Resolvido','Fechado','Concluído'].includes(c.status))
  };
  const lista=filtros[tipo]||cham;
  const sm={};lista.forEach(c=>{const s=c.status||'Aberto';sm[s]=(sm[s]||0)+1;});
  const pm={};lista.forEach(c=>{const p=c.prioridade||'Média';pm[p]=(pm[p]||0)+1;});
  const cm={};lista.forEach(c=>{const cat=c.categoria||'Geral';cm[cat]=(cm[cat]||0)+1;});
  const slSt=Object.entries(sm).filter(x=>x[1]);
  const slPr=Object.entries(pm).filter(x=>x[1]);
  const topC=Object.entries(cm).sort((a,b)=>b[1]-a[1]).slice(0,8);
  const cv1=document.getElementById('cv-ch-ov-status');
  if(cv1&&slSt.length)desenharDonutResponsivo(cv1,slSt.map(x=>x[0]),slSt.map(x=>x[1]),['#f85149','#e3711a','#3fb950','#58a6ff','#8b949e']);
  const cv2=document.getElementById('cv-ch-ov-prio');
  if(cv2&&slPr.length)desenharDonutResponsivo(cv2,slPr.map(x=>x[0]),slPr.map(x=>x[1]),['#f85149','#e3711a','#58a6ff','#8b949e']);
  const cv3=document.getElementById('cv-ch-ov-cat');
  if(cv3&&topC.length){const pw=cv3.parentElement.clientWidth||400;cv3.width=pw;desenharBarrasH('cv-ch-ov-cat',topC.map(x=>x[0]),topC.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7','#58a6ff','#f85149','#8b949e']);}
}

function abrirDetalheChamado(id){
  const {cham}=window._chamData||{};
  if(!cham)return;
  const c=cham.find(x=>x.id===id);
  if(!c)return;
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo)return;
  const badgePrio=p=>{const m={'Alta':'badge-and','Crítica':'badge-susp','Média':'badge-plan','Baixa':'badge-conc'};return`<span class="badge-sm ${m[p]||'badge-plan'}">${p||'—'}</span>`;};
  const badgeSt=s=>{const m={'Aberto':'badge-and','Em Andamento':'badge-plan','Resolvido':'badge-conc','Fechado':'badge-conc','Concluído':'badge-conc','Cancelado':'badge-susp'};return`<span class="badge-sm ${m[s]||'badge-plan'}">${s||'—'}</span>`;};
  const dtFmt=s=>s?(s.slice(0,10).split('-').reverse().join('/')):'—';
  const hist=c.historico||c.comentarios||[];
  conteudo.innerHTML=`
  <div class="ob-ov-header">
    <div class="ob-ov-title">${c.id} — ${c.titulo||'Sem título'}</div>
    <button class="ob-ov-close" onclick="voltarParaDrillChamados()">← voltar</button>
  </div>
  <div class="ob-ov-kpis" style="margin-bottom:12px">
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Status</div><div class="ob-ov-kpi-val" style="margin-top:2px">${badgeSt(c.status)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Prioridade</div><div class="ob-ov-kpi-val" style="margin-top:2px">${badgePrio(c.prioridade)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Categoria</div><div class="ob-ov-kpi-val c-azul" style="font-size:13px">${c.categoria||'—'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Local</div><div class="ob-ov-kpi-val c-azul" style="font-size:13px">${c.local||'—'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Responsável</div><div class="ob-ov-kpi-val" style="font-size:13px;color:${c.responsavel||c.atendente?'var(--green)':'var(--red)'}">${c.responsavel||c.atendente||'⚠ sem resp.'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Solicitante</div><div class="ob-ov-kpi-val" style="font-size:13px">${c.solicitante||'—'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Abertura</div><div class="ob-ov-kpi-val c-azul" style="font-size:13px">${dtFmt(c.dtAbertura||c.dataAbertura||c.criadoEm)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Conclusão</div><div class="ob-ov-kpi-val c-verde" style="font-size:13px">${dtFmt(c.dtConclusao||c.dtFechamento||c.resolvidoEm)}</div></div>
  </div>
  ${c.descricao?`<div class="ob-ov-tbox" style="margin-bottom:12px"><div class="ob-ov-ctit" style="margin-bottom:6px">Descrição</div><div style="font-size:12px;color:var(--text-muted);line-height:1.6">${c.descricao}</div></div>`:''}
  ${hist.length?`<div class="ob-ov-tbox"><div class="ob-ov-ctit" style="margin-bottom:8px">Histórico (${hist.length})</div><table class="ob-ov-table"><thead><tr><th>Data</th><th>Ação / Observação</th><th>Responsável</th></tr></thead><tbody>${hist.map(h=>`<tr><td style="font-family:var(--mono);font-size:10px;color:var(--text-muted);white-space:nowrap">${dtFmt(h.data||h.dt||h.criadoEm)}</td><td style="font-size:11px">${h.acao||h.obs||h.texto||h.descricao||'—'}</td><td style="font-size:11px;color:var(--text-muted)">${h.responsavel||h.autor||'—'}</td></tr>`).join('')}</tbody></table></div>`:''}`;
}

function voltarParaChamados(){
  const d=lerCache(CACHES.chamados);
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo)return;
  _chamDrillAtivo=null;
  conteudo.style.cssText='flex:1;min-height:0;overflow-y:auto';
  renderChamados(conteudo,d);
}

function voltarParaDrillChamados(){
  if(_chamDrillAtivo)abrirDrillChamados(_chamDrillAtivo);
  else voltarParaChamados();
}
/* ══════════════════════════════════════════════
   CONTROLE DE ACESSO
══════════════════════════════════════════════ */
function renderAcesso(container,d){
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de acesso carregado.<br><span style="font-size:10px">Selecione o arquivo no hub principal.</span></div>';return;}
  const pessoas=d.pessoas||[];
  const pontos=d.pontos||[];
  const total=pessoas.length;
  const ativos=pessoas.filter(p=>p.status==='Ativo'||!p.status).length;
  const inativos=total-ativos;
  const semPonto=pessoas.filter(p=>!p.ponto&&!p.pontoId).length;
  const perfilMap={};pessoas.forEach(p=>{const pf=p.perfil||p.cargo||'Operador';perfilMap[pf]=(perfilMap[pf]||0)+1;});
  const deptoMap={};pessoas.forEach(p=>{const dep=p.departamento||p.setor||'';if(dep)deptoMap[dep]=(deptoMap[dep]||0)+1;});
  const topDepto=Object.entries(deptoMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const pontoMap={};pessoas.forEach(p=>{const pt=p.ponto||p.pontoId||'';if(pt)pontoMap[pt]=(pontoMap[pt]||0)+1;});
  const topPonto=Object.entries(pontoMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  const totalPontos=pontos.length||Object.keys(pontoMap).length;

  window._acessoData={pessoas,pontos,perfilMap,deptoMap,topDepto,pontoMap,topPonto,ativos,inativos,semPonto};
  window._acessoDrill=null;

  container.innerHTML=`<div class="mod-section">
    <div class="secao-titulo">Controle de Acesso</div>
    <div class="mod-cards-grid" id="acesso-grid">
      ${mkModCard('ac-total','TOTAL PESSOAS',total,'c-azul','#58a6ff',`${ativos} ativas`,
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Ativas</span><span class="ob-mini-val c-verde">${ativos}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Inativas</span><span class="ob-mini-val c-vermelho">${inativos}</span></div>`)}
      ${mkModCard('ac-sem','SEM PONTO',semPonto,semPonto>0?'c-amarelo':'c-verde','#d29922','ponto não atribuído',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Com ponto</span><span class="ob-mini-val c-verde">${total-semPonto}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">% atribuído</span><span class="ob-mini-val c-azul">${total>0?Math.round((total-semPonto)/total*100):0}%</span></div>`)}
      ${mkModCard('ac-perfis','PERFIS DISTINTOS',Object.keys(perfilMap).length,'c-azul','#a371f7','níveis de acesso',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Maior perfil</span><span class="ob-mini-val c-azul">${Object.entries(perfilMap).sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Departamentos</span><span class="ob-mini-val c-azul">${Object.keys(deptoMap).length}</span></div>`)}
      ${mkModCard('ac-pontos','PONTOS CADASTR.',totalPontos,'c-azul','#58a6ff','leitores / portas',
        `<div class="ob-mini-stat"><span class="ob-mini-lbl">Mais usado</span><span class="ob-mini-val c-azul">${topPonto[0]?topPonto[0][0]:'—'}</span></div>
         <div class="ob-mini-stat"><span class="ob-mini-lbl">Pessoas/ponto</span><span class="ob-mini-val c-azul">${totalPontos>0?Math.round((total-semPonto)/totalPontos):0}</span></div>`)}
    </div>
  </div>`;

  setTimeout(()=>{
    drawModMiniCard('cv-mod-ac-total',['Ativos','Inativos'],[ativos,inativos],['#3fb950','#f85149']);
    const pl=Object.entries(perfilMap).sort((a,b)=>b[1]-a[1]);
    drawModMiniCard('cv-mod-ac-sem',pl.map(x=>x[0]),pl.map(x=>x[1]),['#2E5FA3','#a371f7','#e3711a','#d29922','#3fb950']);
    drawModMiniCard('cv-mod-ac-perfis',topDepto.map(x=>x[0]),topDepto.map(x=>x[1]),['#2E5FA3','#58a6ff','#3fb950','#d29922','#a371f7']);
    drawModMiniCard('cv-mod-ac-pontos',topPonto.map(x=>x[0]),topPonto.map(x=>x[1]),['#58a6ff','#2E5FA3','#3fb950','#e3711a','#a371f7']);
  },60);
}
function abrirDetalheObra(cod){
  if(!_obrasData)return;
  const o=(_obrasData.obras||[]).find(x=>x.cod===cod);
  if(!o)return;
  const b=budgObra(cod),r=realObra(cod),af=calcAvFis(o),pf=b>0?(r/b)*100:0,ef=af-pf;
  const lancsObra=(_obrasData.lancamentos||[]).filter(l=>l.obraCod===cod);
  const mensal={};lancsObra.forEach(l=>{const m=(l.dtLanc||'').slice(0,7);if(m)mensal[m]=(mensal[m]||0)+l.qtd*l.precoUnit;});
  const mKeys=Object.keys(mensal).sort().slice(-8);
  const catMap={};lancsObra.forEach(l=>{const c=l.categoria||'Outros';catMap[c]=(catMap[c]||0)+l.qtd*l.precoUnit;});
  const topCat=Object.entries(catMap).sort((a,b2)=>b2[1]-a[1]).slice(0,6);
  const etapas=o.etapas||[];
  const hoje=new Date();
  const prazo=o.dtFimPrev?Math.floor((new Date(o.dtFimPrev+'T00:00:00')-hoje)/86400000):null;
  const corP=prazo===null?'var(--text-dim)':prazo<0?'var(--red)':prazo<=30?'var(--yellow)':'var(--green)';
  const pb2=(v,c)=>`<div class="ob-mini-prog"><div class="ob-mbar"><div class="ob-mfill" style="width:${Math.min(v,100)}%;background:${c}"></div></div><span style="font-size:9px;font-family:var(--mono);color:var(--text-muted);min-width:34px">${fmt(v,1)}%</span></div>`;
  const badgeSt=s=>{const m={'Em Andamento':'badge-and','Concluído':'badge-conc','Planejado':'badge-plan','Suspenso':'badge-susp'};return`<span class="badge-sm ${m[s]||'badge-plan'}">${s}</span>`;};
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo)return;

  conteudo.innerHTML=`
  <div class="ob-ov-header">
    <div class="ob-ov-title">${o.nome} — Detalhamento</div>
    <button class="ob-ov-close" onclick="voltarParaLista()">← voltar</button>
  </div>

  <div class="ob-ov-kpis" style="grid-template-columns:repeat(8,1fr);margin-bottom:14px">
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Budget</div><div class="ob-ov-kpi-val c-azul">${fmtRK(b)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Realizado</div><div class="ob-ov-kpi-val c-laranja">${fmtRK(r)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Saldo</div><div class="ob-ov-kpi-val ${b-r<0?'c-vermelho':'c-verde'}">${fmtRK(b-r)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Eficiência</div><div class="ob-ov-kpi-val ${ef>5?'c-verde':ef<-5?'c-vermelho':'c-amarelo'}">${ef>=0?'+':''}${fmt(ef,1)}%</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Status</div><div class="ob-ov-kpi-val" style="font-size:13px;margin-top:2px">${badgeSt(o.status)}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Prazo</div><div class="ob-ov-kpi-val" style="font-size:16px;color:${corP}">${prazo===null?'—':prazo<0?'Atrasado':prazo+'d'}</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">Avanço Físico</div><div class="ob-ov-kpi-val ${af>70?'c-verde':af>40?'c-amarelo':'c-laranja'}">${fmt(af,1)}%</div></div>
    <div class="ob-ov-kpi"><div class="ob-ov-kpi-lbl">% Financeiro</div><div class="ob-ov-kpi-val c-azul">${fmt(pf,1)}%</div></div>
  </div>

  <div style="display:grid;grid-template-columns:1fr 260px;gap:10px;margin-bottom:14px">
  <div class="ob-ov-cbox">
    <div class="ob-ov-ctit">Gastos mensais</div>
    <canvas id="cv-det-spark" height="160" style="width:100%;height:160px;display:block"></canvas>
  </div>
  <div class="ob-ov-cbox">
    <div class="ob-ov-ctit">Por categoria</div>
    <canvas id="cv-det-cat" width="260" height="160" style="width:260px;height:160px;display:block"></canvas>
  </div>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
  <div class="ob-ov-cbox">
    <div class="ob-ov-ctit" style="margin-bottom:14px">Avanço físico vs financeiro</div>
    <div id="det-gauge-html"></div>
  </div>
  <div class="ob-ov-cbox">
    <div class="ob-ov-ctit" style="margin-bottom:10px">Budget consumido</div>
    <canvas id="cv-det-budget" height="100" style="width:100%;height:100px;display:block"></canvas>
  </div>
</div>

  ${etapas.length?`
  <div class="ob-ov-tbox" style="margin-bottom:12px">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Etapas (${etapas.length})</div>
    <table class="ob-ov-table">
      <thead><tr><th>Etapa</th><th>Peso</th><th>Avanço Físico</th></tr></thead>
      <tbody>${etapas.map(e=>`<tr>
        <td>${e.nome||e.descricao||'—'}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--text-muted)">${e.peso||1}</td>
        <td style="min-width:200px">${pb2(e.avancoFisico||0,e.avancoFisico>=100?'#3fb950':e.avancoFisico>50?'#58a6ff':'#e3711a')}</td>
      </tr>`).join('')}</tbody>
    </table>
  </div>`:''}

  ${lancsObra.length?`
  <div class="ob-ov-tbox">
    <div class="ob-ov-ctit" style="margin-bottom:8px">Últimos lançamentos (${lancsObra.length})</div>
    <table class="ob-ov-table">
      <thead><tr><th>Data</th><th>Categoria</th><th>Fornecedor</th><th style="text-align:right">Total</th></tr></thead>
      <tbody>${lancsObra.slice().sort((a,b2)=>(b2.dtLanc||'').localeCompare(a.dtLanc||'')).slice(0,10).map(l=>`<tr>
        <td style="font-family:var(--mono);font-size:10px;color:var(--text-muted)">${l.dtLanc?l.dtLanc.split('-').reverse().join('/'):'—'}</td>
        <td style="font-size:10px">${l.categoria||'—'}</td>
        <td style="font-size:10px;color:var(--text-muted)">${l.fornecedor||'—'}</td>
        <td style="font-family:var(--mono);font-size:10px;color:var(--blue-light);text-align:right">${fmtRK(l.qtd*l.precoUnit)}</td>
      </tr>`).join('')}</tbody>
    </table>
  </div>`:'<div class="sem-dados">Sem lançamentos registrados</div>'}`;

  requestAnimationFrame(()=>{
    const cvspark=document.getElementById('cv-det-spark');
    if(cvspark){
      const pw=cvspark.parentElement.clientWidth||400;
      cvspark.width=pw;cvspark.height=160;
      if(mKeys.length>=2){
        desenharSpark('cv-det-spark',mKeys.map(k=>k.slice(5)),mKeys.map(k=>mensal[k]),'#58a6ff');
      } else if(mKeys.length===1){
        const ctx=cvspark.getContext('2d');
        ctx.fillStyle='#2E5FA3';
        ctx.fillRect(20,20,pw-40,120);
        ctx.fillStyle='#8b949e';ctx.font='15px IBM Plex Mono,monospace';ctx.textAlign='center';
        ctx.fillText(mKeys[0].slice(5)+': '+fmtRK(mensal[mKeys[0]]),pw/2,100);
      } else {
        const ctx=cvspark.getContext('2d');
        ctx.fillStyle='#555e6a';ctx.font='15px IBM Plex Mono,monospace';ctx.textAlign='center';
        ctx.fillText('Sem dados mensais',pw/2,80);
      }
    }
    const cvcat=document.getElementById('cv-det-cat');
    if(cvcat&&topCat.length){
      desenharDonutResponsivo(cvcat,topCat.map(x=>x[0]),topCat.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7','#58a6ff']);
    }
    const gaugeEl=document.getElementById('det-gauge-html');
if(gaugeEl){
  const afR=Math.round(af),pfR=Math.round(pf);
  const corAf=afR>=100?'#3fb950':afR>50?'#58a6ff':'#e3711a';
  const corPf=pfR>90?'#f85149':pfR>60?'#d29922':'#3fb950';
  gaugeEl.innerHTML=`
    <div style="margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:10px;color:var(--text-muted)">Avanço físico</span>
        <span style="font-size:14px;font-weight:700;font-family:var(--mono);color:${corAf}">${afR}%</span>
      </div>
      <div style="height:10px;background:var(--border);border-radius:5px;overflow:hidden">
        <div style="height:100%;width:${Math.min(afR,100)}%;background:${corAf};border-radius:5px;transition:width .4s ease"></div>
      </div>
    </div>
    <div style="margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:10px;color:var(--text-muted)">Realizado financeiro</span>
        <span style="font-size:14px;font-weight:700;font-family:var(--mono);color:${corPf}">${pfR}%</span>
      </div>
      <div style="height:10px;background:var(--border);border-radius:5px;overflow:hidden">
        <div style="height:100%;width:${Math.min(pfR,100)}%;background:${corPf};border-radius:5px;transition:width .4s ease"></div>
      </div>
    </div>
    <div style="padding:10px;background:var(--surface);border-radius:6px;border:1px solid var(--border);display:flex;justify-content:space-between;align-items:center">
      <span style="font-size:9px;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em">Eficiência (físico - financeiro)</span>
      <span style="font-size:18px;font-weight:700;font-family:var(--mono);color:${ef>5?'#3fb950':ef<-5?'#f85149':'#d29922'}">${ef>=0?'+':''}${fmt(ef,1)}%</span>
    </div>`;
}
const cvbudget=document.getElementById('cv-det-budget');
if(cvbudget&&b>0){
  const pw=cvbudget.parentElement.clientWidth||400;
  cvbudget.width=pw;cvbudget.height=100;
  desenharBarrasH('cv-det-budget',
    ['Budget','Realizado','Saldo'],
    [b,r,Math.max(b-r,0)],
    ['#2E5FA3','#e3711a',b-r<0?'#f85149':'#3fb950']
  );
}
  });
}
function voltarParaSubCards(){
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo||!_obrasData)return;
  _drillOb=null;
  document.getElementById('ob-overlay')?.remove();
  conteudo.style.cssText='flex:1;min-height:0;display:flex;flex-direction:column;overflow-y:auto';
  conteudo.innerHTML='<div class="obras-section"><div class="secao-titulo">Obras</div>'+buildObrasCards(_obrasData)+'</div>';
  setTimeout(()=>{
    drawMiniCard('total',_obrasData);
    drawMiniCard('andamento',_obrasData);
    drawMiniCard('concluidas',_obrasData);
    drawMiniCard('planejadas',_obrasData);
  },60);
}
function voltarParaLista(){
  const conteudo=document.querySelector('#painel-expandido-global > div:last-child');
  if(!conteudo||!_obrasData)return;
  const tipo=_drillOb||'total';
  conteudo.innerHTML='';
  conteudo.style.cssText='flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden';
  const overlay=document.createElement('div');
  overlay.className='ob-overlay';
  overlay.id='ob-overlay';
  overlay.innerHTML=buildOverlayHTML(tipo,_obrasData);
  conteudo.appendChild(overlay);
  setTimeout(()=>drawOverlayCharts(tipo,_obrasData),60);
}

function mkModCard(id,label,val,valCls,accent,sub,statsHtml){
  return`<div class="ob-card" id="ob-card-${id}">
    <div class="ob-card-head">
      <div class="ob-card-accent" style="background:${accent}"></div>
      <div class="ob-card-label">${label}</div>
      <div class="ob-card-val ${valCls}">${val!==null&&val!==undefined?val:'—'}</div>
      <div class="ob-card-sub">${sub}</div>
    </div>
    <div class="ob-card-body">
      <div class="ob-chart-wrap"><canvas id="cv-mod-${id}"></canvas></div>
      ${statsHtml}
    </div>
  </div>`;
}

function drawModMiniCard(canvasId,labels,vals,cores){
  const cv=document.getElementById(canvasId);
  if(!cv)return;
  const pw=cv.parentElement.clientWidth||180;
  const ph=cv.parentElement.clientHeight||120;
  cv.width=pw;cv.height=ph;
  if(!labels.length||!vals.length)return;
  desenharDonutResponsivo(cv,labels,vals,cores);
}
function renderCapex(container,d){
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo CAPEX carregado.</div>';return;}
  const obras=d.obras||[];
  const budget=d.budget||[];
  const lanc=d.lancamentos||[];
  const budgTotal=budget.reduce((s,b)=>s+(b.budgetAprov||0),0);
  const real=lanc.reduce((s,l)=>s+l.qtd*l.precoUnit,0);
  const saldo=budgTotal-real;
  const pct=budgTotal>0?Math.round(real/budgTotal*100):0;
  const emAnd=obras.filter(o=>o.status==='Em Andamento');
  const conc=obras.filter(o=>o.status==='Concluído');
  const plan=obras.filter(o=>o.status==='Planejado');
  const budgCx=cod=>budget.filter(b=>b.obraCod===cod).reduce((s,b)=>s+(b.budgetAprov||0),0);
const realCx=cod=>lanc.filter(l=>l.obraCod===cod).reduce((s,l)=>s+l.qtd*l.precoUnit,0);
const saldoCx=cod=>budgCx(cod)-realCx(cod);
  const catMap={};lanc.forEach(l=>{const c=l.categoria||'Outros';catMap[c]=(catMap[c]||0)+l.qtd*l.precoUnit;});
  const topCat=Object.entries(catMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
  container.innerHTML=`<div class="obras-section"><div class="secao-titulo">CAPEX</div><div class="obras-cards-grid" id="capex-grid">
    ${mkCard('cx-budget','BUDGET TOTAL',fmtRK(budgTotal),'c-azul','#2E5FA3',pct+'% realizado',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Realizado</span><span class="ob-mini-val c-laranja">${fmtRK(real)}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Saldo</span><span class="ob-mini-val ${saldo<0?'c-vermelho':'c-verde'}">${fmtRK(saldo)}</span></div>`)}
    ${mkCard('cx-andamento','EM ANDAMENTO',emAnd.length,'c-laranja','#e3711a',fmtRK(emAnd.reduce((s,o)=>s+budgObra(o.cod),0))+' budget',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Realizado</span><span class="ob-mini-val c-laranja">${fmtRK(emAnd.reduce((s,o)=>s+realObra(o.cod),0))}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Saldo</span><span class="ob-mini-val c-verde">${fmtRK(emAnd.reduce((s,o)=>s+saldoObra(o.cod),0))}</span></div>`)}
    ${mkCard('cx-conc','CONCLUÍDAS',conc.length,'c-verde','#3fb950',fmtRK(conc.reduce((s,o)=>s+realObra(o.cod),0))+' gasto',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">% do total</span><span class="ob-mini-val c-verde">${obras.length>0?Math.round(conc.length/obras.length*100):0}%</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Obras</span><span class="ob-mini-val c-verde">${conc.length}</span></div>`)}
    ${mkCard('cx-cat','POR CATEGORIA',topCat.length,'c-azul','#a371f7',topCat[0]?topCat[0][0]+': '+fmtRK(topCat[0][1]):'—',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Top categoria</span><span class="ob-mini-val c-azul">${topCat[0]?topCat[0][0]:'—'}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Categorias</span><span class="ob-mini-val c-azul">${Object.keys(catMap).length}</span></div>`)}
  </div></div>`;
  setTimeout(()=>{
    const sm={};obras.forEach(o=>{sm[o.status]=(sm[o.status]||0)+1;});
    const sl=Object.entries(sm).filter(x=>x[1]);
    desenharDonutNaCanvas('cv-mini-cx-budget',sl.map(x=>x[0]),sl.map(x=>x[1]),['#e3711a','#3fb950','#2E5FA3','#f85149']);
    desenharDonutNaCanvas('cv-mini-cx-andamento',emAnd.map(o=>tnome(o.nome)),emAnd.map(o=>Math.max(budgObra(o.cod),1)),['#e3711a','#d29922','#2E5FA3','#a371f7']);
    desenharDonutNaCanvas('cv-mini-cx-conc',['Realizado','Budget restante'],[real||1,Math.max(budgTotal-real,0)||1],['#3fb950','#2E5FA3']);
    desenharDonutNaCanvas('cv-mini-cx-cat',topCat.map(x=>x[0]),topCat.map(x=>x[1]),['#2E5FA3','#e3711a','#3fb950','#d29922','#a371f7']);
  },60);
}

function renderCodin(container,d){
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo CODIN carregado.</div>';return;}
  const pessoas=d.pessoas||[];
  const pontos=d.pontos||[];
  const total=pessoas.length;
  const ativos=pessoas.filter(p=>p.status==='Ativo'||!p.status).length;
  const inativos=total-ativos;
  const semPonto=pessoas.filter(p=>!p.ponto&&!p.pontoId).length;
  const perfilMap={};pessoas.forEach(p=>{const pf=p.perfil||p.cargo||'Operador';perfilMap[pf]=(perfilMap[pf]||0)+1;});
  const deptoMap={};pessoas.forEach(p=>{const dep=p.departamento||p.setor||'';if(dep)deptoMap[dep]=(deptoMap[dep]||0)+1;});
  const totalPontos=pontos.length||Object.keys({...pessoas.reduce((m,p)=>{if(p.ponto||p.pontoId)m[p.ponto||p.pontoId]=1;return m;},{})}).length;
  container.innerHTML=`<div class="obras-section"><div class="secao-titulo">CODIN — Controle de Acesso</div><div class="obras-cards-grid" id="codin-grid">
    ${mkCard('cd-total','TOTAL PESSOAS',total,'c-azul','#2E5FA3',ativos+' ativas',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Ativas</span><span class="ob-mini-val c-verde">${ativos}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Inativas</span><span class="ob-mini-val c-vermelho">${inativos}</span></div>`)}
    ${mkCard('cd-ponto','SEM PONTO',semPonto,semPonto>0?'c-amarelo':'c-verde','#d29922','ponto não atribuído',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Com ponto</span><span class="ob-mini-val c-verde">${total-semPonto}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">% atribuído</span><span class="ob-mini-val c-azul">${total>0?Math.round((total-semPonto)/total*100):0}%</span></div>`)}
    ${mkCard('cd-perfis','PERFIS',Object.keys(perfilMap).length,'c-azul','#a371f7','níveis de acesso',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Maior perfil</span><span class="ob-mini-val c-azul">${Object.entries(perfilMap).sort((a,b)=>b[1]-a[1])[0]?.[0]||'—'}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Departamentos</span><span class="ob-mini-val c-azul">${Object.keys(deptoMap).length}</span></div>`)}
    ${mkCard('cd-pontos','PONTOS CADASTR.',totalPontos,'c-azul','#58a6ff','leitores / portas',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Pessoas/ponto</span><span class="ob-mini-val c-azul">${totalPontos>0?Math.round((total-semPonto)/totalPontos):0}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Sem ponto</span><span class="ob-mini-val c-amarelo">${semPonto}</span></div>`)}
  </div></div>`;
  setTimeout(()=>{
    desenharDonutNaCanvas('cv-mini-cd-total',['Ativos','Inativos'],[ativos||1,inativos||1],['#3fb950','#f85149']);
    desenharDonutNaCanvas('cv-mini-cd-ponto',['Com ponto','Sem ponto'],[total-semPonto||1,semPonto||1],['#2E5FA3','#d29922']);
    const pl=Object.entries(perfilMap).sort((a,b)=>b[1]-a[1]);
    desenharDonutNaCanvas('cv-mini-cd-perfis',pl.map(x=>x[0]),pl.map(x=>x[1]),['#2E5FA3','#a371f7','#e3711a','#d29922','#3fb950']);
    const topDep=Object.entries(deptoMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
    desenharDonutNaCanvas('cv-mini-cd-pontos',topDep.map(x=>x[0]),topDep.map(x=>x[1]),['#58a6ff','#2E5FA3','#3fb950','#d29922','#a371f7']);
  },60);
}

function renderConforto(container,d){
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de Conforto carregado.</div>';return;}
  const registros=d.registros||[];
  const total=registros.length;
  const conform=registros.filter(r=>r.status==='Conforme'||r.situacao==='OK').length;
  const nconf=registros.filter(r=>r.status==='Não Conforme'||r.situacao==='NOK').length;
  const areas=new Set(registros.map(r=>r.area||r.local||'')).size;
  const tempMedia=registros.filter(r=>r.temperatura).reduce((s,r,_,a)=>s+r.temperatura/a.length,0);
  container.innerHTML=`<div class="obras-section"><div class="secao-titulo">Conforto Ambiental</div><div class="obras-cards-grid" id="conforto-grid">
    ${mkCard('cf-total','TOTAL REGISTROS',total,'c-azul','#2E5FA3',areas+' áreas monitoradas',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Conformes</span><span class="ob-mini-val c-verde">${conform}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Não conformes</span><span class="ob-mini-val c-vermelho">${nconf}</span></div>`)}
    ${mkCard('cf-conf','CONFORMIDADE',total>0?Math.round(conform/total*100)+'%':'—',conform/Math.max(total,1)>.8?'c-verde':'c-vermelho','#3fb950',conform+' de '+total+' OK',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Não conformes</span><span class="ob-mini-val c-vermelho">${nconf}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Taxa</span><span class="ob-mini-val ${conform/Math.max(total,1)>.8?'c-verde':'c-vermelho'}">${total>0?Math.round(conform/total*100):0}%</span></div>`)}
    ${mkCard('cf-temp','TEMPERATURA',tempMedia>0?fmt(tempMedia,1)+'°C':'—',tempMedia>28?'c-vermelho':tempMedia>25?'c-amarelo':'c-verde','#e3711a','média ambiente',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Registros temp.</span><span class="ob-mini-val c-azul">${registros.filter(r=>r.temperatura).length}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Áreas</span><span class="ob-mini-val c-azul">${areas}</span></div>`)}
    ${mkCard('cf-areas','ÁREAS',areas||'—','c-azul','#a371f7','monitoradas',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Com alerta</span><span class="ob-mini-val c-vermelho">${nconf}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">OK</span><span class="ob-mini-val c-verde">${conform}</span></div>`)}
  </div></div>`;
  setTimeout(()=>{
    desenharDonutNaCanvas('cv-mini-cf-total',['Conforme','Não Conforme'],[conform||1,nconf||1],['#3fb950','#f85149']);
    desenharDonutNaCanvas('cv-mini-cf-conf',['Conforme','Não Conforme'],[conform||1,nconf||1],['#3fb950','#c0392b']);
    const areaMap={};registros.forEach(r=>{const a=r.area||r.local||'Sem área';areaMap[a]=(areaMap[a]||0)+1;});
    const topA=Object.entries(areaMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
    desenharDonutNaCanvas('cv-mini-cf-temp',topA.map(x=>x[0]),topA.map(x=>x[1]),['#e3711a','#d29922','#2E5FA3','#3fb950','#a371f7']);
    desenharDonutNaCanvas('cv-mini-cf-areas',topA.map(x=>x[0]),topA.map(x=>x[1]),['#2E5FA3','#58a6ff','#3fb950','#d29922','#a371f7']);
  },60);
}

function renderErgonomia(container,d){
  if(!d){container.innerHTML='<div class="sem-dados">Nenhum arquivo de Ergonomia carregado.</div>';return;}
  const avaliacoes=d.avaliacoes||[];
  const total=avaliacoes.length;
  const ok=avaliacoes.filter(a=>a.resultado==='OK'||a.status==='Aprovado').length;
  const nok=avaliacoes.filter(a=>a.resultado==='NOK'||a.status==='Reprovado').length;
  const pendentes=total-ok-nok;
  const postos=new Set(avaliacoes.map(a=>a.posto||a.local||'')).size;
  container.innerHTML=`<div class="obras-section"><div class="secao-titulo">Ergonomia</div><div class="obras-cards-grid" id="ergonomia-grid">
    ${mkCard('eg-total','AVALIAÇÕES',total,'c-azul','#2E5FA3',postos+' postos avaliados',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Aprovadas</span><span class="ob-mini-val c-verde">${ok}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Reprovadas</span><span class="ob-mini-val c-vermelho">${nok}</span></div>`)}
    ${mkCard('eg-ok','APROVADAS',ok,'c-verde','#3fb950',total>0?Math.round(ok/total*100)+'% do total':'—',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Taxa aprovação</span><span class="ob-mini-val c-verde">${total>0?Math.round(ok/total*100):0}%</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Postos OK</span><span class="ob-mini-val c-verde">${ok}</span></div>`)}
    ${mkCard('eg-nok','REPROVADAS',nok,nok>0?'c-vermelho':'c-verde','#f85149',nok>0?'ação necessária':'dentro do padrão',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Pendentes</span><span class="ob-mini-val c-amarelo">${pendentes}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Críticas</span><span class="ob-mini-val c-vermelho">${avaliacoes.filter(a=>a.criticidade==='Alta'||a.risco==='Alto').length}</span></div>`)}
    ${mkCard('eg-postos','POSTOS',postos||'—','c-azul','#a371f7','avaliados',
      `<div class="ob-mini-stat"><span class="ob-mini-lbl">Pendentes</span><span class="ob-mini-val c-amarelo">${pendentes}</span></div>
       <div class="ob-mini-stat"><span class="ob-mini-lbl">Concluídos</span><span class="ob-mini-val c-verde">${ok+nok}</span></div>`)}
  </div></div>`;
  setTimeout(()=>{
    desenharDonutNaCanvas('cv-mini-eg-total',['Aprovadas','Reprovadas','Pendentes'],[ok||1,nok||1,pendentes||1],['#3fb950','#f85149','#d29922']);
    desenharDonutNaCanvas('cv-mini-eg-ok',['Aprovadas','Restantes'],[ok||1,(nok+pendentes)||1],['#3fb950','#d0d8e8']);
    desenharDonutNaCanvas('cv-mini-eg-nok',['Reprovadas','Aprovadas','Pendentes'],[nok||1,ok||1,pendentes||1],['#f85149','#3fb950','#d29922']);
    const postoMap={};avaliacoes.forEach(a=>{const p=a.posto||a.local||'Sem posto';postoMap[p]=(postoMap[p]||0)+1;});
    const topP=Object.entries(postoMap).sort((a,b)=>b[1]-a[1]).slice(0,5);
    desenharDonutNaCanvas('cv-mini-eg-postos',topP.map(x=>x[0]),topP.map(x=>x[1]),['#2E5FA3','#58a6ff','#3fb950','#d29922','#a371f7']);
  },60);
}

function desenharDonutNaCanvas(canvasId,labels,vals,cores){
  const cv=document.getElementById(canvasId);
  if(!cv)return;
  cv.width=cv.parentElement.clientWidth||180;
  cv.height=cv.parentElement.clientHeight||120;
  desenharDonutResponsivo(cv,labels,vals,cores);
}
function expandirLegenda(e,tipo){
  e.stopPropagation();
  const btn=e.currentTarget;
  const labels=JSON.parse(btn.dataset.labels);
  const vals=JSON.parse(btn.dataset.vals);
  const cores=JSON.parse(btn.dataset.cores);
  const usarValor=btn.dataset.usarvalor==='true';
  const tot=vals.reduce((a,b)=>a+b,0);
  const overlay=document.createElement('div');
  overlay.id='leg-overlay';
  overlay.style.cssText='position:fixed;inset:0;background:rgba(15,28,63,.45);z-index:500;display:flex;align-items:center;justify-content:center';
  overlay.onclick=()=>overlay.remove();
  const box=document.createElement('div');
  box.style.cssText='background:var(--surface);border:1px solid var(--border);border-radius:14px;padding:20px 24px;min-width:320px;max-width:480px;max-height:80vh;overflow-y:auto;box-shadow:0 8px 32px rgba(36,55,130,.18)';
  box.onclick=e=>e.stopPropagation();
  box.innerHTML=`<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
    <span style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:var(--text-muted)">Legenda completa</span>
    <button onclick="document.getElementById('leg-overlay').remove()" style="background:none;border:1px solid var(--border);border-radius:5px;padding:3px 10px;cursor:pointer;font-size:11px;color:var(--text-muted);font-family:var(--font)">✕ fechar</button>
  </div>
  ${labels.map((l,i)=>{
    const v=usarValor?Math.round(vals[i]):Math.round(vals[i]/tot*100)+'%';
    return`<div style="display:flex;align-items:center;gap:8px;padding:7px 0;border-bottom:1px solid var(--border)">
      <span style="width:10px;height:10px;border-radius:50%;background:${cores[i%cores.length]};flex-shrink:0;display:inline-block"></span>
      <span style="flex:1;font-size:12px;color:var(--text)">${l}</span>
      <span style="font-size:12px;font-weight:700;font-family:var(--mono);color:var(--text)">${v}</span>
    </div>`;
  }).join('')}`;
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}
function carregarCache(chave){return!!localStorage.getItem(chave);}