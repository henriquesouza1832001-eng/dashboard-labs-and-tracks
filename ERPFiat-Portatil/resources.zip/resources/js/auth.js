'use strict';
// Não utilizado