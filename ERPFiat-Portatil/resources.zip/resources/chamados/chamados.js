window.onerror = function(msg, src, line, col, err) {
  var bar = document.getElementById('debug-bar');
  if(bar){ bar.style.display='block'; bar.textContent += 'ERRO linha '+line+': '+msg+'\n'; }
};
window.addEventListener('unhandledrejection', function(e){
  var bar = document.getElementById('debug-bar');
  if(bar){ bar.style.display='block'; bar.textContent += 'PROMISE: '+(e.reason?.stack||e.reason)+'\n'; }
});
const $ = id => document.getElementById(id);
const STORAGE_KEY = 'chamados-facilities-path';
const DATA_KEY    = 'chamados-facilities-dados';
const SLA_KEY = 'chamados-sla-config';

const CATS = {
  INF: { label: 'Infraestrutura', prefix: 'INF', color: '#58a6ff' },
  ELE: { label: 'Elétrica',       prefix: 'ELE', color: '#d29922' },
  HID: { label: 'Hidráulica',     prefix: 'HID', color: '#3fb950' },
  LMP: { label: 'Limpeza',        prefix: 'LMP', color: '#bc8cff' },
  AR:  { label: 'Ar Cond.',       prefix: 'AR',  color: '#39c5cf' },
};
function lerSLA() {
  try { return JSON.parse(localStorage.getItem(SLA_KEY)) || {}; } catch(e) { return {}; }
}
function slaParaPrio(prio) {
  const sla = lerSLA();
  const pad = { 'Crítica':1, 'Alta':3, 'Média':5, 'Baixa':7 };
  return (sla[prio] || pad[prio] || 7);
}
function diasAberto(c) {
  const inicio = new Date(c.dataAbertura);
  const fim = c.dataConclusao ? new Date(c.dataConclusao) : new Date();
  return Math.max(0, (fim - inicio) / 86400000);
}
function dentroDeSLA(c) {
  return diasAberto(c) <= slaParaPrio(c.prioridade);
}
function salvarSLA() {
  const cfg = {
    'Crítica': parseInt($('sla-critica').value) || 1,
    'Alta':    parseInt($('sla-alta').value)    || 3,
    'Média':   parseInt($('sla-media').value)   || 5,
    'Baixa':   parseInt($('sla-baixa').value)   || 7,
  };
  localStorage.setItem(SLA_KEY, JSON.stringify(cfg));
  showToast('SLA salvo!');
  renderDashboard();
}
function carregarCamposSLA() {
  const sla = lerSLA();
  $('sla-critica').value = sla['Crítica'] || 1;
  $('sla-alta').value    = sla['Alta']    || 3;
  $('sla-media').value   = sla['Média']   || 5;
  $('sla-baixa').value   = sla['Baixa']   || 7;
}
let allChamados    = [];
let filteredList   = [];
let activeStatus   = '';
let activeCat      = '';
let activePrio     = '';
let currentId      = null;  
let fileHandle     = null;   
let novasFotos     = [];    
let editFotos      = [];     

// ============================================================
// UTILS
// ============================================================
function fmtDate(iso) {
  if (!iso) return '–';
  try { return new Date(iso).toLocaleString('pt-BR', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit' }); }
  catch { return iso; }
}
function fmtDateShort(iso) {
  if (!iso) return '–';
  try { return new Date(iso).toLocaleString('pt-BR', { day:'2-digit', month:'2-digit', year:'numeric' }); }
  catch { return iso; }
}
function statusClass(s) {
  const m = { 'Aberto':'s-aberto','Em Andamento':'s-andamento','Concluído':'s-concluido','Cancelado':'s-cancelado' };
  return m[s] || '';
}
function prioClass(p) {
  const m = { 'Baixa':'p-baixa','Média':'p-media','Alta':'p-alta','Crítica':'p-critica' };
  return m[p] || '';
}
let toastTimer;
function showToast(msg, type='ok') {
  const t = $('toast');
  t.className = `toast ${type} show`;
  $('toast-msg').textContent = msg;
  $('toast-icon').innerHTML = type === 'ok'
    ? '<polyline points="20 6 9 17 4 12"/>'
    : '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>';
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3500);
}
function setSave(state, label) {
  const el = $('save-status');
  el.className = 'save-status ' + state;
  $('save-label').textContent = label;
}
function lerPath() { return localStorage.getItem(STORAGE_KEY); }
function salvarPath(v) { localStorage.setItem(STORAGE_KEY, v); }

// gera ID sequencial por categoria: INF-2025-001
function gerarId(cat) {
  const ano = new Date().getFullYear();
  const prefix = cat + '-' + ano + '-';
  const existentes = allChamados
    .filter(c => c.id && c.id.startsWith(prefix))
    .map(c => parseInt(c.id.replace(prefix, '')) || 0);
  const prox = existentes.length ? Math.max(...existentes) + 1 : 1;
  return prefix + String(prox).padStart(3, '0');
}
async function salvarArquivo() {
  const txt = JSON.stringify({ chamados: allChamados }, null, 2);
  localStorage.setItem(DATA_KEY, txt);
  if (!fileHandle) { setSave('nosave', 'sem arquivo'); return; }
  setSave('saving', 'salvando…');
  try {
    const w = await fileHandle.createWritable();
    await w.write(txt);
    await w.close();
    setSave('saved', 'salvo');
  } catch(e) {
    setSave('err', 'erro ao salvar');
  }
}
function abrirArquivo() {
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = '.json,application/json';
  inp.style.display = 'none';
  document.body.appendChild(inp);
  inp.onchange = async () => {
    const file = inp.files && inp.files[0];
    document.body.removeChild(inp);
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async e => {
      try {
        const txt = e.target.result;
        const json = JSON.parse(txt);
        allChamados = json.chamados || [];
        localStorage.setItem(DATA_KEY, txt);
        localStorage.setItem('neu-name-cham', file.name);
        setSave('saved', file.name);
        atualizarContadores();
        aplicarFiltros();
        showToast(`${allChamados.length} chamado(s) carregado(s)`);
        try {
          fileHandle = await window.showSaveFilePicker({
            suggestedName: file.name,
            types: [{ description: 'JSON', accept: {'application/json': ['.json']} }]
          });
          const w = await fileHandle.createWritable();
          await w.write(txt);
          await w.close();
          setSave('saved', 'pronto para salvar');
        } catch(err) {
          if (err.name !== 'AbortError') setSave('nosave', 'somente leitura');
        }
      } catch(err) {
        showToast('Erro ao ler arquivo', 'err');
      }
    };
    reader.readAsText(file, 'UTF-8');
  };
  inp.click();
}
async function carregarDoArquivo() {
  try {
    const txt = await Neutralino.filesystem.readFile(fileHandle);
    const json = JSON.parse(txt);
    allChamados = json.chamados || [];
    setSave('saved','salvo');
    atualizarContadores();
    aplicarFiltros();
    showToast(`${allChamados.length} chamado(s) carregado(s)`);
  } catch(e) {
    allChamados = [];
    setSave('saved','arquivo novo');
    atualizarContadores();
    aplicarFiltros();
  }
}

function tentarCarregarCache() {
  const txt = localStorage.getItem(DATA_KEY);
  if (!txt) { renderTabela(); return; }
  try {
    const json = JSON.parse(txt);
    allChamados = json.chamados || [];
    setSave('saved', 'salvo');
    atualizarContadores();
    aplicarFiltros();
  } catch(e) {
    renderTabela();
  }
}
function atualizarContadores() {
  const hoje = new Date().toDateString();
  $('cnt-todos').textContent     = allChamados.length;
  $('cnt-aberto').textContent    = allChamados.filter(c=>c.status==='Aberto').length;
  $('cnt-andamento').textContent = allChamados.filter(c=>c.status==='Em Andamento').length;
  $('cnt-concluido').textContent = allChamados.filter(c=>c.status==='Concluído').length;
  $('cnt-cancelado').textContent = allChamados.filter(c=>c.status==='Cancelado').length;
  $('cnt-call').textContent      = allChamados.length;
  Object.keys(CATS).forEach(k => {
    const el = $('cnt-'+k);
    if (el) el.textContent = allChamados.filter(c=>c.categoria===k).length;
  });
  $('cnt-critica').textContent = allChamados.filter(c=>c.prioridade==='Crítica').length;
  $('cnt-alta').textContent    = allChamados.filter(c=>c.prioridade==='Alta').length;
  $('cnt-media').textContent   = allChamados.filter(c=>c.prioridade==='Média').length;
  $('cnt-baixa').textContent   = allChamados.filter(c=>c.prioridade==='Baixa').length;
  $('stat-hoje').textContent      = allChamados.filter(c=>c.dataAbertura && new Date(c.dataAbertura).toDateString()===hoje).length;
  $('stat-andamento').textContent = allChamados.filter(c=>c.status==='Em Andamento').length;
  $('stat-criticos').textContent  = allChamados.filter(c=>c.prioridade==='Crítica' && c.status==='Aberto').length;
  $('stat-sem-resp').textContent  = allChamados.filter(c=>!c.responsavel).length;
}

function aplicarFiltros() {
  const q = $('search-input').value.toLowerCase();
  filteredList = allChamados.filter(c => {
    if (activeStatus && c.status !== activeStatus) return false;
    if (activeCat    && c.categoria !== activeCat) return false;
    if (activePrio   && c.prioridade !== activePrio) return false;
    if (q) {
      const hay = [c.id, c.titulo, c.local, c.solicitante, c.responsavel, c.idExterno].join(' ').toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
  renderTabela();
}

// ============================================================
// RENDER TABELA
// ============================================================
function renderTabela() {
  const tbody = $('chamados-tbody');
  if (!allChamados.length && !fileHandle) {
    tbody.innerHTML = `<tr><td colspan="8">
      <div class="empty-state">
        <svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
        <p>Nenhum arquivo carregado.</p>
        <button class="btn btn-ghost" onclick="abrirArquivo()">
          <svg viewBox="0 0 24 24"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
          Abrir arquivo JSON
        </button>
      </div>
    </td></tr>`;
    return;
  }
  if (!filteredList.length) {
    tbody.innerHTML = `<tr><td colspan="8">
      <div class="empty-state">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <p>Nenhum chamado encontrado.</p>
      </div>
    </td></tr>`;
    return;
  }
  // ordenar: abertos/andamento primeiro, depois data desc
  const ordem = { 'Aberto':0, 'Em Andamento':1, 'Cancelado':2, 'Concluído':3 };
  const sorted = [...filteredList].sort((a,b) => {
    const d = (ordem[a.status]??9) - (ordem[b.status]??9);
    if (d !== 0) return d;
    return new Date(b.dataAbertura) - new Date(a.dataAbertura);
  });
  tbody.innerHTML = sorted.map(c => {
    const cat = CATS[c.categoria] || { label: c.categoria, color: '#8b949e' };
    return `<tr data-id="${c.id}">
      <td><span class="id-badge">${c.id}</span></td>
      <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${c.titulo || '–'}</td>
      <td><span class="cat-badge"><span class="cat-dot c-${c.categoria}"></span>${cat.label}</span></td>
      <td style="color:var(--text-muted);font-size:12px">${c.local || '–'}</td>
      <td><span class="status-badge ${statusClass(c.status)}"><span class="dot"></span>${c.status}</span></td>
      <td><span class="prio-badge ${prioClass(c.prioridade)}">${c.prioridade}</span></td>
      <td style="font-size:12px;color:${c.responsavel?'var(--text)':'var(--red)'}">${c.responsavel||'<span style="font-size:11px">⚠ sem resp.</span>'}</td>
      <td style="color:var(--text-muted);font-size:12px;font-family:var(--mono)">${fmtDateShort(c.dataAbertura)}</td>
    </tr>`;
  }).join('');
  tbody.querySelectorAll('tr').forEach(tr => {
    tr.addEventListener('click', () => abrirModalVer(tr.dataset.id));
  });
}

// ============================================================
// MODAL VER / EDITAR
// ============================================================
function abrirModalVer(id) {
  const c = allChamados.find(x => x.id === id);
  if (!c) return;
  currentId = id;
  editFotos = c.fotos ? [...c.fotos] : [];

  const cat = CATS[c.categoria] || { label: c.categoria };
  $('mv-titulo').textContent    = c.titulo || '–';
  $('mv-id').textContent        = c.id;
  $('mv-subtitle').textContent  = `${cat.label} • ${c.local || '–'} • aberto por ${c.solicitante || 'desconhecido'}`;
  $('mv-data').textContent      = fmtDate(c.dataAbertura);
  $('mv-cat').textContent       = cat.label;
  $('mv-local').textContent     = c.local || '–';
  $('mv-desc').textContent      = c.descricao || '–';
  $('mv-status').value          = c.status || 'Aberto';
  $('mv-prio').value            = c.prioridade || 'Média';
  $('mv-responsavel').value     = c.responsavel || '';
  $('mv-idext').value           = c.idExterno || '';
  $('mv-dataconclusao').value   = c.dataConclusao ? c.dataConclusao.substring(0,16) : '';
  $('mv-obs').value             = '';

  renderFotosGrid('mv-fotos-grid', editFotos, 'mv-add-foto', true);
  renderTimeline(c.historico || []);
  $('modal-ver').classList.add('open');
}

function renderTimeline(hist) {
  const tl = $('mv-timeline');
  if (!hist.length) {
    tl.innerHTML = '<div style="color:var(--text-muted);font-size:12px;padding:8px 0">Nenhuma atualização ainda.</div>';
    return;
  }
  tl.innerHTML = [...hist].reverse().map((h,i,arr) => `
    <div class="tl-item">
      <div class="tl-dot-col">
        <div class="tl-dot" style="background:${h.cor||'var(--blue-mid)'}"></div>
        ${i < arr.length-1 ? '<div class="tl-line"></div>' : ''}
      </div>
      <div class="tl-content">
        <div class="tl-action">${h.acao}</div>
        ${h.obs ? `<div style="color:var(--text-muted);font-size:12px;margin-top:3px">${h.obs}</div>` : ''}
        <div class="tl-meta">${fmtDate(h.data)}</div>
      </div>
    </div>
  `).join('');
}

function fecharModalVer() {
  $('modal-ver').classList.remove('open');
  currentId = null;
  editFotos = [];
}

async function salvarChamado() {
  if (!currentId) return;
  const idx = allChamados.findIndex(c => c.id === currentId);
  if (idx < 0) return;
  const c = allChamados[idx];
  const novoStatus = $('mv-status').value;
  const novaPrio   = $('mv-prio').value;
  const obs        = $('mv-obs').value.trim();

  // registrar histórico
  const ent = [];
  if (novoStatus !== c.status)    ent.push(`Status: ${c.status} → ${novoStatus}`);
  if (novaPrio !== c.prioridade)  ent.push(`Prioridade: ${c.prioridade} → ${novaPrio}`);
  const respNovo = $('mv-responsavel').value.trim();
  if (respNovo !== (c.responsavel||'')) ent.push(`Responsável: ${respNovo||'–'}`);
  const extNovo = $('mv-idext').value.trim();
  if (extNovo !== (c.idExterno||'')) ent.push(`ID Externo: ${extNovo||'–'}`);
  if (obs) ent.push(obs ? null : null); // obs vai como campo separado

  const corMap = { 'Aberto':'#58a6ff','Em Andamento':'#d29922','Concluído':'#3fb950','Cancelado':'#8b949e' };
  if (ent.length || obs) {
    const historico = c.historico || [];
    historico.push({
      data: new Date().toISOString(),
      acao: ent.length ? ent.join(' · ') : 'Atualização',
      obs: obs || '',
      cor: corMap[novoStatus] || 'var(--blue-mid)'
    });
    c.historico = historico;
  }

  c.status        = novoStatus;
  c.prioridade    = novaPrio;
  c.responsavel   = respNovo;
  c.idExterno     = extNovo;
  c.dataConclusao = $('mv-dataconclusao').value ? new Date($('mv-dataconclusao').value).toISOString() : c.dataConclusao;
  if (obs) c.ultimaObs = obs;
  c.fotos = [...editFotos];

  await salvarArquivo();
  atualizarContadores();
  aplicarFiltros();
  fecharModalVer();
  showToast('Chamado atualizado!');
}

async function excluirChamado() {
  if (!currentId) return;
  if (!confirm(`Excluir o chamado ${currentId}? Não é possível desfazer.`)) return;
  allChamados = allChamados.filter(c => c.id !== currentId);
  await salvarArquivo();
  atualizarContadores();
  aplicarFiltros();
  fecharModalVer();
  showToast('Chamado excluído.');
}

// ============================================================
// MODAL NOVO CHAMADO
// ============================================================
function abrirModalNovo() {
  novasFotos = [];
  $('mn-titulo').value      = '';
  $('mn-cat').value         = '';
  $('mn-prio').value        = 'Média';
  $('mn-local').value       = '';
  $('mn-solicitante').value = '';
  $('mn-desc').value        = '';
  renderFotosGrid('mn-fotos-grid', novasFotos, 'mn-add-foto', false);
  $('modal-novo').classList.add('open');
  setTimeout(() => $('mn-titulo').focus(), 100);
}

function fecharModalNovo() {
  $('modal-novo').classList.remove('open');
  novasFotos = [];
}

async function registrarChamado() {
  const titulo = $('mn-titulo').value.trim();
  const cat    = $('mn-cat').value;
  const local  = $('mn-local').value.trim();
  const desc   = $('mn-desc').value.trim();
  if (!titulo || !cat || !local || !desc) {
    showToast('Preencha título, categoria, local e descrição.', 'err');
    return;
  }
  const id = gerarId(cat);
  const novo = {
    id,
    titulo,
    categoria: cat,
    prioridade: $('mn-prio').value,
    local,
    solicitante: $('mn-solicitante').value.trim(),
    descricao: desc,
    status: 'Aberto',
    responsavel: '',
    idExterno: '',
    dataAbertura: new Date().toISOString(),
    dataConclusao: null,
    fotos: [...novasFotos],
    historico: [{
      data: new Date().toISOString(),
      acao: 'Chamado aberto',
      obs: desc,
      cor: '#58a6ff'
    }]
  };
  allChamados.unshift(novo);
  await salvarArquivo();
  atualizarContadores();
  aplicarFiltros();
  fecharModalNovo();
  showToast(`Chamado ${id} registrado!`);
}

// ============================================================
// FOTOS
// ============================================================
function renderFotosGrid(gridId, arr, addBtnId, editMode) {
  const grid = $(gridId);
  // mantém o botão de adicionar, remove thumbs anteriores
  const addBtn = $(addBtnId);
  grid.innerHTML = '';
  arr.forEach((b64, i) => {
    const thumb = document.createElement('div');
    thumb.className = 'foto-thumb';
    thumb.innerHTML = `
      <img src="${b64}" alt="foto ${i+1}">
      <button class="rm-foto" data-i="${i}" title="Remover foto">
        <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
      </button>
    `;
    thumb.querySelector('img').addEventListener('click', () => abrirFotoViewer(b64));
    thumb.querySelector('.rm-foto').addEventListener('click', e => {
      e.stopPropagation();
      arr.splice(i, 1);
      renderFotosGrid(gridId, arr, addBtnId, editMode);
    });
    grid.appendChild(thumb);
  });
  grid.appendChild(addBtn);
}

function abrirFotoViewer(src) {
  $('foto-viewer-img').src = src;
  $('foto-viewer').classList.add('open');
}

function lerImagens(input, arr, gridId, addBtnId, editMode) {
  const files = Array.from(input.files);
  if (!files.length) return;
  let loaded = 0;
  files.forEach(f => {
    const reader = new FileReader();
    reader.onload = e => {
      arr.push(e.target.result);
      loaded++;
      if (loaded === files.length) renderFotosGrid(gridId, arr, addBtnId, editMode);
    };
    reader.readAsDataURL(f);
  });
  input.value = '';
}

// ============================================================
// EVENTOS
// ============================================================
$('btn-open-file').addEventListener('click', abrirArquivo);
$('btn-novo').addEventListener('click', abrirModalNovo);

// filtros sidebar
document.querySelectorAll('[data-filter]').forEach(btn => {
  btn.addEventListener('click', () => {
    const type = btn.dataset.filter;
    const val  = btn.dataset.val;
    document.querySelectorAll(`[data-filter="${type}"]`).forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    if (type === 'status') activeStatus = val;
    if (type === 'cat')    activeCat    = val;
    if (type === 'prio')   activePrio   = val;
    aplicarFiltros();
  });
});

$('search-input').addEventListener('input', aplicarFiltros);

// modal ver
$('mv-close').addEventListener('click', fecharModalVer);
$('mv-cancelar').addEventListener('click', fecharModalVer);
$('mv-salvar').addEventListener('click', salvarChamado);
$('mv-excluir').addEventListener('click', excluirChamado);
$('modal-ver').addEventListener('click', e => { if (e.target === $('modal-ver')) fecharModalVer(); });

$('mv-add-foto').addEventListener('click', () => $('mv-file-input').click());
$('mv-file-input').addEventListener('change', e => {
  lerImagens(e.target, editFotos, 'mv-fotos-grid', 'mv-add-foto', true);
});

// modal novo
$('mn-close').addEventListener('click', fecharModalNovo);
$('mn-cancelar').addEventListener('click', fecharModalNovo);
$('mn-salvar').addEventListener('click', registrarChamado);
$('modal-novo').addEventListener('click', e => { if (e.target === $('modal-novo')) fecharModalNovo(); });

$('mn-add-foto').addEventListener('click', () => $('mn-file-input').click());
$('mn-file-input').addEventListener('change', e => {
  lerImagens(e.target, novasFotos, 'mn-fotos-grid', 'mn-add-foto', false);
});
$('foto-viewer-close').addEventListener('click', () => $('foto-viewer').classList.remove('open'));
$('foto-viewer').addEventListener('click', e => { if (e.target === $('foto-viewer')) $('foto-viewer').classList.remove('open'); });
$('mn-titulo').addEventListener('keydown', e => { if (e.key === 'Enter') $('mn-cat').focus(); });
// ── TOGGLE SEÇÃO SIDEBAR ──
function toggleSection(id) {
  document.getElementById(id).classList.toggle('collapsed');
}

// ── TABS ──
let chartInstances = {};
function setTab(tab) {
  document.getElementById('tab-lista').classList.toggle('active', tab === 'lista');
  document.getElementById('tab-dash').classList.toggle('active', tab === 'dash');
  document.getElementById('tab-config').classList.toggle('active', tab === 'config');
  document.getElementById('view-lista').style.display  = tab === 'lista'  ? '' : 'none';
  document.getElementById('view-dash').style.display   = tab === 'dash'   ? '' : 'none';
  document.getElementById('view-config').style.display = tab === 'config' ? '' : 'none';
  document.getElementById('wrap-search').style.display = tab === 'lista'  ? '' : 'none';
  if (tab === 'dash')   renderDashboard();
  if (tab === 'config') carregarCamposSLA();
}

// ── DASHBOARD ──
function renderDashboard() {
  const c = allChamados;
  const total = c.length;
  const abertos    = c.filter(x => x.status === 'Aberto').length;
  const andamento  = c.filter(x => x.status === 'Em Andamento').length;
  const concluidos = c.filter(x => x.status === 'Concluído').length;
  const cancelados = c.filter(x => x.status === 'Cancelado').length;
  const criticos   = c.filter(x => x.prioridade === 'Crítica' && x.status !== 'Concluído').length;
  const semResp    = c.filter(x => !x.responsavel).length;
  const pctConclusao = total ? Math.round(concluidos / total * 100) : 0;
const comData   = c.filter(x => x.dataAbertura);
const noSLA     = comData.filter(x => dentroDeSLA(x)).length;
const foraSLA   = comData.length - noSLA;
const pctSLA    = comData.length ? Math.round(noSLA / comData.length * 100) : 100;
const slaMeta   = 90;
const prioSLA = ['Crítica','Alta','Média','Baixa'].map(p => {
  const lista = comData.filter(x => x.prioridade === p);
  const ok    = lista.filter(x => dentroDeSLA(x)).length;
  const pct   = lista.length ? Math.round(ok / lista.length * 100) : 100;
  return { p, total: lista.length, ok, pct };
});

$('indicadores-list').innerHTML = [
  { label: 'Total de chamados',    val: total,            color: 'var(--text)' },
  { label: 'Taxa de conclusão',    val: pctConclusao+'%', color: 'var(--green)' },
  { label: 'Críticos em aberto',   val: criticos,         color: criticos > 0 ? 'var(--red)' : 'var(--green)' },
  { label: 'Sem responsável',      val: semResp,          color: semResp > 0 ? 'var(--yellow)' : 'var(--green)' },
  { label: 'Em andamento',         val: andamento,        color: 'var(--yellow)' },
].map(r => `
  <div class="indicador-row">
    <span>${r.label}</span>
    <span class="indicador-val" style="color:${r.color}">${r.val}</span>
  </div>
`).join('');
const corSLA = pctSLA >= slaMeta ? 'var(--green)' : pctSLA >= 70 ? 'var(--yellow)' : 'var(--red)';
const slaEl = document.getElementById('sla-painel');
if (slaEl) {
  slaEl.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
      <span style="font-size:12px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em">SLA Geral</span>
      <span style="font-family:var(--mono);font-size:22px;font-weight:700;color:${corSLA}">${pctSLA}%</span>
    </div>
    <div style="height:6px;background:var(--border);border-radius:3px;overflow:hidden;margin-bottom:4px">
      <div style="height:100%;width:${pctSLA}%;background:${corSLA};border-radius:3px;transition:width .4s"></div>
    </div>
    <div style="font-size:10px;color:var(--text-muted);margin-bottom:14px">Meta: ${slaMeta}% · ${noSLA} dentro · ${foraSLA} fora</div>
    ${prioSLA.map(x => {
      const cor = x.pct >= slaMeta ? 'var(--green)' : x.pct >= 70 ? 'var(--yellow)' : 'var(--red)';
      const cores = {'Crítica':'var(--red)','Alta':'var(--orange)','Média':'var(--blue-light)','Baixa':'var(--text-muted)'};
      return `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:11px;color:${cores[x.p]||'var(--text-muted)'};min-width:52px">${x.p}</span>
        <div style="flex:1;height:5px;background:var(--border);border-radius:3px;overflow:hidden">
          <div style="height:100%;width:${x.pct}%;background:${cor};border-radius:3px"></div>
        </div>
        <span style="font-family:var(--mono);font-size:11px;font-weight:700;color:${cor};min-width:36px;text-align:right">${x.pct}%</span>
        <span style="font-size:10px;color:var(--text-muted);min-width:40px">${x.ok}/${x.total}</span>
      </div>`;
    }).join('')}
  `;
}

const gridC = 'rgba(0,0,0,0.07)', textC = '#4a5880';
const baseScale = { grid: { color: gridC }, ticks: { color: textC, font: { size: 10, family: 'IBM Plex Mono' } } };
  Object.values(chartInstances).forEach(ch => ch.destroy());
  chartInstances = {};
  chartInstances.status = new Chart($('chart-status'), {
    type: 'doughnut',
    data: {
      labels: ['Aberto', 'Em Andamento', 'Concluído', 'Cancelado'],
      datasets: [{ data: [abertos, andamento, concluidos, cancelados],
        backgroundColor: ['#58a6ff', '#d29922', '#3fb950', '#8b949e'],
        borderWidth: 0, hoverOffset: 4 }]
    },
    options: { responsive: true, maintainAspectRatio: false, cutout: '65%',
      plugins: { legend: { position: 'bottom', labels: { color: '#4a5880', font: { size: 11, family: 'IBM Plex Sans' }, boxWidth: 10, padding: 16 } } } }
  });
  const catLabels = Object.values(CATS).map(c => c.label);
  const catVals   = Object.keys(CATS).map(k => allChamados.filter(x => x.categoria === k).length);
  const catColors = ['#58a6ff', '#d29922', '#3fb950', '#bc8cff', '#39c5cf'];
  chartInstances.cat = new Chart($('chart-cat'), {
    type: 'bar',
    data: { labels: catLabels, datasets: [{ data: catVals, backgroundColor: catColors, borderRadius: 4, borderSkipped: false }] },
    options: {
  indexAxis: 'y',
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: false } },
  scales: {
    x: {
      grid: { color: gridC },
      ticks: { color: textC, font: { size: 10, family: 'IBM Plex Mono' }, stepSize: 1 },
      border: { display: false }
    },
    y: {
      grid: { display: false },
      ticks: { color: textC, font: { size: 11, family: 'IBM Plex Sans' } },
      border: { display: false }
    }
  }
}
  });
  const prioLabels = ['Crítica', 'Alta', 'Média', 'Baixa'];
  const prioVals   = prioLabels.map(p => allChamados.filter(x => x.prioridade === p && x.status !== 'Concluído' && x.status !== 'Cancelado').length);
  const prioColors = ['#f85149', '#e3711a', '#58a6ff', '#8b949e'];
  chartInstances.prio = new Chart($('chart-prio'), {
    type: 'bar',
    data: { labels: prioLabels, datasets: [{ data: prioVals, backgroundColor: prioColors, borderRadius: 4, borderSkipped: false }] },
    options: {
  responsive: true,
  maintainAspectRatio: false,
  plugins: { legend: { display: false } },
  scales: {
    x: {
      grid: { display: false },
      ticks: { color: textC, font: { size: 11, family: 'IBM Plex Sans' } },
      border: { display: false }
    },
    y: {
      grid: { color: gridC },
      ticks: { color: textC, font: { size: 10, family: 'IBM Plex Mono' }, stepSize: 1 },
      border: { display: false }
    }
  }
}
  });
}
tentarCarregarCache();